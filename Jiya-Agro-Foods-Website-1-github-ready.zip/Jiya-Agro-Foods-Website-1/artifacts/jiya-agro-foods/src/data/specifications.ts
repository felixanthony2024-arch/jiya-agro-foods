export type SpecRow = { label: string; value: string; note?: string };

export type ProductSpec =
  | { kind: "typical"; rows: SpecRow[] }
  | { kind: "enquiry" };

const shelfLife = "12–24 months in sealed packing";
const packing = "Food-grade poly-lined cartons or bags for bulk orders. Custom pack sizes on request.";
const storage = "Keep in a cool, dry place away from sunlight. Reseal after opening.";

export const specifications: Record<string, ProductSpec> = {
  "garlic-powder": {
    kind: "typical",
    rows: [
      { label: "Colour", value: "Creamy white" },
      { label: "Mesh", value: "80–120 mesh (custom available)" },
      { label: "Moisture", value: "≤ 6%" },
      { label: "Texture", value: "Fine, free-flowing" },
      { label: "Shelf life", value: shelfLife },
      { label: "Packing", value: packing },
      { label: "Storage", value: "See general storage guidance under How to use.", note: "General guidance" },
    ],
  },
  "garlic-flakes": {
    kind: "typical",
    rows: [
      { label: "Colour", value: "Creamy white to light golden" },
      { label: "Form", value: "Whole slices / flakes" },
      { label: "Moisture", value: "≤ 6%" },
      { label: "Taste & aroma", value: "Strong, typical of garlic" },
      { label: "Shelf life", value: shelfLife },
      { label: "Packing", value: packing },
      { label: "Storage", value: storage },
    ],
  },
  "red-onion-flakes": {
    kind: "typical",
    rows: [
      { label: "Colour", value: "Pink to light red" },
      { label: "Flake size", value: "8–20 mm (custom cuts available)" },
      { label: "Moisture", value: "≤ 6%" },
      { label: "Taste & aroma", value: "Strong, typical of red onion" },
      { label: "Shelf life", value: shelfLife },
      { label: "Packing", value: packing },
      { label: "Storage", value: storage },
    ],
  },
  "white-onion-flakes": {
    kind: "typical",
    rows: [
      { label: "Colour", value: "White to creamy white" },
      { label: "Flake size", value: "8–20 mm (custom cuts available)" },
      { label: "Moisture", value: "≤ 6%" },
      { label: "Taste & aroma", value: "Typical of fresh white onion" },
      { label: "Shelf life", value: shelfLife },
      { label: "Packing", value: packing },
      { label: "Storage", value: storage },
    ],
  },
  "onion-powder": {
    kind: "typical",
    rows: [
      { label: "Colour", value: "White" },
      { label: "Mesh", value: "80–100 mesh (custom available)" },
      { label: "Moisture", value: "3.60% observed; maximum 6%" },
      { label: "Texture", value: "Fine, free-flowing" },
      { label: "Shelf life", value: shelfLife },
      { label: "Packing", value: packing },
      { label: "Storage", value: storage },
    ],
  },
};

export const getSpecification = (slug: string): ProductSpec =>
  specifications[slug] ?? { kind: "enquiry" };
