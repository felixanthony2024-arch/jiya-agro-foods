export type Product = {
  slug: string;
  name: string;
  short: string;
  family: "Onion" | "Garlic";
  form: "Powder" | "Flakes";
  image: string;
  siteImage: string;
  tone: string;
  summary: string;
  description: string;
  benefits: { title: string; text: string }[];
  applications: string[];
  howToUse: string[];
};

const img = (f: string) => `${import.meta.env.BASE_URL}images/${f}`;

const storage = "Store in a dry, airtight container, away from moisture, heat and direct sunlight. Reseal promptly after each use.";

export const products: Product[] = [
  {
    slug: "onion-powder",
    name: "Dehydrated Onion Powder",
    short: "Onion Powder",
    family: "Onion",
    form: "Powder",
    image: img("onion-powder-updated.jpeg"),
    siteImage: img("onion-powder-updated.jpeg"),
    tone: "38 62% 62%",
    summary: "Dehydrated onion, finely ground for even blending.",
    description:
      "Processed, dehydrated onions finely ground into a powder that carries the characteristic flavour and aroma of onion. It blends into dry mixes and liquids alike, and is easy to store, handle and measure batch after batch.",
    benefits: [
      { title: "Blends evenly", text: "A fine grind disperses through seasonings, rubs and sauces." },
      { title: "Characteristic flavour", text: "Brings the familiar savoury taste and aroma of onion to a recipe." },
      { title: "Easy to store and handle", text: "No peeling, chopping or fresh-produce waste in the kitchen or on the line." },
      { title: "Consistency", text: "A uniform ingredient helps recipes stay steady from one run to the next." },
    ],
    applications: ["Soups", "Sauces", "Curries", "Marinades", "Seasonings", "Snacks", "Ready-to-eat foods"],
    howToUse: [
      "Add gradually and taste as you go until the flavour suits the dish.",
      "For even dispersion, mix the powder into a little water, stock or oil before adding to a larger batch.",
      "Combine with other dry spices for rubs, masalas and snack coatings.",
      storage,
    ],
  },
  {
    slug: "garlic-powder",
    name: "Dehydrated Garlic Powder",
    short: "Garlic Powder",
    family: "Garlic",
    form: "Powder",
    image: img("up-onion-powder.jpeg"),
    siteImage: img("up-onion-powder.jpeg"),
    tone: "44 40% 82%",
    summary: "Dehydrated garlic, finely ground for convenient seasoning.",
    description:
      "Processed, dehydrated garlic finely ground into a powder with the characteristic flavour and aroma of garlic. A convenient way to season without peeling cloves, and simple to store and portion consistently.",
    benefits: [
      { title: "No peeling, no sticky hands", text: "Skip the cloves and go straight to seasoning." },
      { title: "Characteristic flavour", text: "The pungent, savoury aroma of garlic in a pantry-friendly form." },
      { title: "Easy to store and handle", text: "A dry ingredient that fits neatly into blending and kitchen routines." },
      { title: "Consistency", text: "Fine, uniform texture for repeatable recipes." },
    ],
    applications: ["Soups", "Sauces", "Curries", "Marinades", "Seasonings", "Snacks", "Bakery", "Pizza", "Chutney", "Pickle", "Ready-to-eat foods"],
    howToUse: [
      "Add gradually to taste; garlic powder is easy to overdo, so start small.",
      "Mix into a little liquid or oil first for smooth dispersion in sauces and marinades.",
      "Sprinkle into dough, pizza toppings or seasoning blends.",
      storage,
    ],
  },
  {
    slug: "red-onion-flakes",
    name: "Dehydrated Red Onion Flakes",
    short: "Red Onion Flakes",
    family: "Onion",
    form: "Flakes",
    image: img("up-red-onion-flakes.jpeg"),
    siteImage: img("red-onion-flakes.png"),
    tone: "336 45% 55%",
    summary: "Sliced, dehydrated red onion with body and colour.",
    description:
      "Processed, dehydrated red onions in flake form, carrying the characteristic flavour and aroma of red onion. Flakes give texture to a dish and are easy to store and handle compared with fresh onion. Also available in kibbled form by enquiry.",
    benefits: [
      { title: "Texture and colour", text: "Flakes bring visible body to gravies, toppings and blends." },
      { title: "Characteristic flavour", text: "The familiar taste and aroma of red onion." },
      { title: "Easy to store and handle", text: "No peeling or chopping, and less fresh-produce handling." },
      { title: "Consistency", text: "A dependable, uniform ingredient for repeat production." },
    ],
    applications: ["Soups", "Sauces", "Curries", "Marinades", "Seasonings", "Snacks", "Ready-to-eat foods"],
    howToUse: [
      "Rehydrate in water until the flakes reach the texture you want, then drain and use.",
      "Or add directly to a simmering, moist dish such as a curry or soup and let them soften as it cooks.",
      "Use dry in seasoning blends and snack mixes where a crisp bite is welcome.",
      storage,
    ],
  },
  {
    slug: "garlic-flakes",
    name: "Dehydrated Garlic Flakes",
    short: "Garlic Flakes",
    family: "Garlic",
    form: "Flakes",
    image: img("up-garlic-flakes.jpeg"),
    siteImage: img("garlic-flakes.png"),
    tone: "32 58% 58%",
    summary: "Dehydrated garlic slices with a bold, savoury aroma.",
    description:
      "Processed, dehydrated garlic in flake form, with the characteristic flavour and aroma of garlic. Flakes are convenient to store and handle and bring texture to the dish. Kibbled and powder forms are also available by enquiry.",
    benefits: [
      { title: "Ready without peeling", text: "Garlic flavour without cleaning and slicing cloves." },
      { title: "Characteristic flavour", text: "Savoury, aromatic garlic character." },
      { title: "Easy to store and handle", text: "A dry ingredient that keeps the prep table simpler." },
      { title: "Consistency", text: "Uniform pieces for steady recipes." },
    ],
    applications: ["Soups", "Sauces", "Curries", "Marinades", "Seasonings", "Snacks", "Bakery", "Pizza", "Chutney", "Pickle", "Ready-to-eat foods"],
    howToUse: [
      "Rehydrate in water until the desired texture, or simmer directly in a moist dish.",
      "Add to tempering, chutneys and pickles according to your recipe and taste.",
      "Crush or grind lightly for toppings and seasoning blends.",
      storage,
    ],
  },
  {
    slug: "white-onion-flakes",
    name: "Dehydrated White Onion Flakes",
    short: "White Onion Flakes",
    family: "Onion",
    form: "Flakes",
    image: img("up-white-onion-flakes.jpeg"),
    siteImage: img("white-onion-flakes.png"),
    tone: "48 45% 80%",
    summary: "Pale, crisp flakes with the mild character of white onion.",
    description:
      "Processed, dehydrated white onions in flake form, with the characteristic flavour and aroma of white onion. Easy to store and handle, and a consistent alternative to fresh onion prep. Kibbled and powder forms are also available by enquiry.",
    benefits: [
      { title: "No peeling, no tears", text: "Skip the peeling, cutting and onion waste." },
      { title: "Characteristic flavour", text: "The taste and aroma of white onion in a dry form." },
      { title: "Easy to store and handle", text: "Simple to keep in a pantry, kitchen or plant store." },
      { title: "Consistency", text: "Uniform cut for recipes that stay steady." },
    ],
    applications: ["Soups", "Sauces", "Curries", "Marinades", "Seasonings", "Snacks", "Ready-to-eat foods", "Salads (after preparation)", "Sandwiches (after preparation)"],
    howToUse: [
      "Rehydrate in water until the flakes reach the texture you want.",
      "For salads and sandwiches, rehydrate and drain well before using.",
      "Or add straight into a simmering, moist dish to soften as it cooks.",
      storage,
    ],
  },
];

export const getProduct = (slug: string) => products.find((p) => p.slug === slug);
export const imgPath = img;
