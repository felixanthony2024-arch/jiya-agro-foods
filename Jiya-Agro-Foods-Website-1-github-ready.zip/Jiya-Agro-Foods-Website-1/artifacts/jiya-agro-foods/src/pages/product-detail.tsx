import { Link, useParams } from "wouter";
import { ArrowLeft, Check, Info } from "lucide-react";
import { getProduct, products } from "@/data/products";
import { usePageMeta, waLink } from "@/lib/site";
import { Eyebrow, ProductCard, Reveal } from "@/components/bits";
import NotFound from "@/pages/not-found";
import { getSpecification } from "@/data/specifications";

export default function ProductDetail() {
  const { slug = "" } = useParams<{ slug: string }>();
  const p = getProduct(slug);
  usePageMeta(p ? p.name : "Product not found", p ? `${p.summary} Applications, benefits and general how-to-use guidance from Jiya Agro Foods.` : "Product not found.");
  if (!p) return <NotFound />;
  const spec = getSpecification(p.slug);
  const others = products.filter((x) => x.slug !== p.slug).slice(0, 3);

  return (
    <>
      <div className="mx-auto max-w-7xl px-5 pt-8">
        <Link href="/products" className="inline-flex items-center gap-2 text-sm font-mono hover:text-accent" data-testid="link-back"><ArrowLeft className="h-4 w-4" /> All products</Link>
      </div>
      <section className="mx-auto max-w-7xl px-5 py-10 grid md:grid-cols-2 gap-10 lg:gap-16 items-start">
        <Reveal className="md:sticky md:top-28">
          <div className="rounded-[2rem] overflow-hidden bg-[hsl(150_30%_8%)] shadow-lg relative">
            <img src={p.image} alt={p.name} className="w-full aspect-square object-cover" data-testid="img-product" />
            <span className="absolute bottom-0 left-0 right-0 h-2" style={{ background: `hsl(${p.tone})` }} />
          </div>
          <div className="mt-4 flex items-center gap-4 rounded-2xl border bg-card p-3">
            <img src={p.siteImage} alt={`${p.short} as shown on the current Jiya website`} className="h-16 w-16 rounded-xl object-cover" loading="lazy" />
            <p className="text-sm text-muted-foreground">Also pictured on our current website.</p>
          </div>
        </Reveal>
        <div>
          <Eyebrow>{p.family} / {p.form}</Eyebrow>
          <h1 className="mt-3 text-4xl md:text-6xl text-primary leading-[1]" data-testid="text-product-name">{p.name}</h1>
          <p className="mt-6 text-lg leading-relaxed text-muted-foreground">{p.description}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href={`/contact?product=${p.slug}`} className="rounded-full bg-accent text-accent-foreground px-6 py-3.5" data-testid="button-enquire">Enquire about this product</Link>
            <a href={waLink(`Hello Jiya Agro Foods, I'd like details on ${p.name}.`)} target="_blank" rel="noopener noreferrer" className="rounded-full border-2 border-primary/20 px-6 py-3.5 hover:border-primary">WhatsApp</a>
          </div>

          <h2 className="mt-14 text-3xl">Practical benefits</h2>
          <ul className="mt-5 grid sm:grid-cols-2 gap-4">
            {p.benefits.map((b) => (
              <li key={b.title} className="rounded-2xl bg-card border p-5">
                <Check className="h-5 w-5 text-secondary" />
                <p className="font-medium mt-3">{b.title}</p>
                <p className="text-sm text-muted-foreground mt-1">{b.text}</p>
              </li>
            ))}
          </ul>

          <h2 className="mt-14 text-3xl">Applications</h2>
          <div className="mt-5 flex flex-wrap gap-2">
            {p.applications.map((a) => <span key={a} className="rounded-full bg-secondary/25 px-4 py-2 text-sm">{a}</span>)}
          </div>

          <section className="mt-14" aria-labelledby="spec-heading" data-testid="section-specifications">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <h2 id="spec-heading" className="text-3xl">{spec.kind === "typical" ? "Typical specifications" : "Specifications"}</h2>
              <span className="text-xs font-mono uppercase tracking-wider text-accent">{spec.kind === "typical" ? "Indicative, not batch-certified" : "On enquiry"}</span>
            </div>
            {spec.kind === "typical" ? (
              <div className="mt-5 rounded-2xl border bg-card overflow-hidden relative">
                <span aria-hidden className="absolute left-0 top-0 bottom-0 w-1.5" style={{ background: `hsl(${p.tone})` }} />
                <table className="w-full text-left text-sm" data-testid="table-specifications">
                  <caption className="sr-only">Typical specifications for {p.name}</caption>
                  <tbody>
                    {spec.rows.map((r) => (
                      <tr key={r.label} className="border-b last:border-b-0 flex flex-col sm:table-row pl-4 sm:pl-0">
                        <th scope="row" className="pt-4 sm:py-4 sm:pl-7 sm:pr-4 sm:w-[38%] align-top font-mono text-xs uppercase tracking-wider text-muted-foreground font-normal">{r.label}</th>
                        <td className="pb-4 pt-1 pr-5 sm:py-4 align-top">
                          {r.value}
                          {r.note && <span className="ml-2 inline-block rounded-full bg-muted px-2 py-0.5 text-[11px] font-mono uppercase tracking-wider text-muted-foreground">{r.note}</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="mt-5 rounded-2xl border border-dashed bg-card p-6" data-testid="text-specifications-enquiry">
                <p className="font-medium">Specifications available on enquiry.</p>
                <p className="mt-1 text-sm text-muted-foreground">Share your intended application and we will confirm grade, form and packing for {p.short.toLowerCase()}.</p>
              </div>
            )}
            {spec.kind === "typical" && <p className="mt-3 text-sm text-muted-foreground">Typical values only. Please confirm final grade and batch requirements with our sales team.</p>}
          </section>

          <h2 className="mt-14 text-3xl">How to use</h2>
          <p className="mt-2 text-sm font-mono text-accent uppercase tracking-wider">General culinary guidance</p>
          <ol className="mt-5 space-y-4">
            {p.howToUse.map((h, i) => (
              <li key={i} className="flex gap-4"><span className="font-display text-2xl text-secondary w-6">{i + 1}</span><p className="pt-1">{h}</p></li>
            ))}
          </ol>
          <div className="mt-10 rounded-2xl bg-muted p-5 flex gap-3 text-sm text-muted-foreground">
            <Info className="h-5 w-5 shrink-0 text-primary" />
            <p>Pricing, MOQ and batch-specific requirements are available on enquiry. Usage guidance above is general; confirm final specifications for your order with our sales team.</p>
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-5 py-16">
        <h2 className="text-3xl mb-8">More from the shelf</h2>
        <div className="grid md:grid-cols-3 gap-5">{others.map((o) => <ProductCard key={o.slug} p={o} />)}</div>
      </section>
    </>
  );
}
