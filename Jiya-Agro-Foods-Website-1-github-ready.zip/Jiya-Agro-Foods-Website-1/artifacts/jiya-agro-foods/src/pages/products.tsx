import { useMemo, useState } from "react";
import { Search, X } from "lucide-react";
import { products } from "@/data/products";
import { usePageMeta } from "@/lib/site";
import { Eyebrow, ProductCard, Reveal } from "@/components/bits";

const FILTERS = ["All", "Onion", "Garlic", "Flakes", "Powder"] as const;

export default function Products() {
  usePageMeta("Product Catalogue", "Browse Jiya Agro Foods dehydrated onion powder, garlic powder, red and white onion flakes and garlic flakes.");
  const [q, setQ] = useState("");
  const [f, setF] = useState<(typeof FILTERS)[number]>("All");
  const list = useMemo(() => {
    const s = q.toLowerCase().trim();
    return products.filter((p) =>
      (f === "All" || p.family === f || p.form === f) &&
      (!s || [p.name, p.summary, p.description, ...p.applications].join(" ").toLowerCase().includes(s)));
  }, [q, f]);

  return (
    <div className="mx-auto max-w-7xl px-5 py-16">
      <Reveal className="text-center">
        <Eyebrow>Catalogue</Eyebrow>
        <h1 className="mt-3 text-5xl md:text-7xl text-primary">Our products</h1>
        <p className="mt-4 text-muted-foreground max-w-xl mx-auto">White and red onion are also available in kibbled form. Specifications, MOQ, packaging and pricing by enquiry.</p>
      </Reveal>
      <div className="mt-10 flex flex-col md:flex-row gap-4 md:items-center justify-between">
        <div className="relative md:w-96">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <label htmlFor="search" className="sr-only">Search products</label>
          <input id="search" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or use, e.g. pickle"
            className="w-full rounded-full border bg-card pl-11 pr-10 py-3 outline-none focus:ring-2 focus:ring-ring" data-testid="input-search" />
          {q && <button onClick={() => setQ("")} aria-label="Clear search" className="absolute right-3 top-1/2 -translate-y-1/2 p-1"><X className="h-4 w-4" /></button>}
        </div>
        <div className="flex flex-wrap gap-2" role="group" aria-label="Filter">
          {FILTERS.map((x) => (
            <button key={x} onClick={() => setF(x)} aria-pressed={f === x} data-testid={`button-filter-${x.toLowerCase()}`}
              className={`rounded-full px-4 py-2 text-sm border transition-colors ${f === x ? "bg-primary text-primary-foreground border-primary" : "hover:bg-muted"}`}>{x}</button>
          ))}
        </div>
      </div>
      {list.length ? (
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((p, i) => <Reveal key={p.slug} delay={i * 0.05}><ProductCard p={p} /></Reveal>)}
        </div>
      ) : (
        <div className="mt-16 rounded-3xl border-2 border-dashed p-14 text-center">
          <p className="font-display text-3xl">Nothing on this shelf.</p>
          <p className="text-muted-foreground mt-2">Try another word, or ask the assistant in the corner.</p>
          <button onClick={() => { setQ(""); setF("All"); }} className="mt-6 rounded-full bg-primary text-primary-foreground px-5 py-2.5">Reset filters</button>
        </div>
      )}
    </div>
  );
}
