import { Link } from "wouter";
import { usePageMeta } from "@/lib/site";

export default function NotFound() {
  usePageMeta("Page not found", "This page could not be found on Jiya Agro Foods.");
  return (
    <div className="mx-auto max-w-3xl px-5 py-28 text-center">
      <p className="font-mono text-sm text-accent tracking-[0.2em] uppercase">404</p>
      <h1 className="mt-4 text-5xl md:text-7xl text-primary">This field is empty.</h1>
      <p className="mt-4 text-muted-foreground">The page you were looking for isn't here.</p>
      <div className="mt-8 flex justify-center gap-3">
        <Link href="/" className="rounded-full bg-primary text-primary-foreground px-6 py-3">Go home</Link>
        <Link href="/products" className="rounded-full border px-6 py-3">See products</Link>
      </div>
    </div>
  );
}
