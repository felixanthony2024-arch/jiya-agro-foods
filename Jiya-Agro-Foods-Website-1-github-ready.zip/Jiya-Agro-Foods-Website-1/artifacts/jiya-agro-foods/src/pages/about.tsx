import { Link } from "wouter";
import { usePageMeta } from "@/lib/site";
import { Eyebrow, Reveal, Leaf } from "@/components/bits";

export default function About() {
  usePageMeta("Our Story", "Meet Jiya Agro Foods, an Indian manufacturer and supplier of premium dehydrated onion and garlic ingredients for food processors and commercial kitchens.");
  return (
    <>
      <section className="mx-auto max-w-7xl px-5 py-16 grid md:grid-cols-12 gap-10 items-end">
        <Reveal className="md:col-span-7">
          <Eyebrow>Our story</Eyebrow>
          <h1 className="mt-3 text-5xl md:text-7xl text-primary leading-[0.95]">Premium dehydrated ingredients, from farm to facility.</h1>
        </Reveal>
        <Reveal className="md:col-span-5" delay={0.1}>
          <h2 className="text-3xl mb-4">Who we are</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">Rooted in India's agricultural heartland, Jiya Agro Foods specializes in processing and supplying premium dehydrated ingredients. We bridge the gap between farm harvests and modern commercial food production with consistent, reliable inputs.</p>
        </Reveal>
      </section>
      <section className="mx-auto max-w-5xl px-5 py-24 grid md:grid-cols-2 gap-14">
        {[
          {
            title: "What we offer",
            description: "Our dehydrated vegetable range is processed to retain characteristic flavour and aroma while making ingredients easier to use and store.",
            points: [
              { title: "Dehydrated onions", description: "White and red varieties in kibbled, flake, powder and granule forms." },
              { title: "Dehydrated garlic", description: "Garlic flakes and powder for convenient use in recipes and commercial food production." },
            ],
          },
          {
            title: "Why dehydrated ingredients?",
            description: "Reduce daily preparation without compromising the onion and garlic flavour your recipes depend on.",
            points: [
              { title: "Consistent quality", description: "A focus on uniform flavour, aroma and colour for repeatable results throughout the year." },
              { title: "Operational efficiency", description: "No peeling, chopping or washing required, helping reduce preparation time in busy kitchens." },
              { title: "Optimised storage", description: "Lightweight, space-saving ingredients with an extended shelf life when stored as directed." },
            ],
          },
          {
            title: "Our process & standards",
            description: "From farm-gate sourcing to controlled dehydration and careful processing, we connect agricultural produce with the needs of commercial food production. Our focus is on purity, moisture control and consistent ingredients that meet agreed commercial specifications.",
            points: [
              { title: "Made for your requirements", description: "Confirm product grade, moisture limits, packaging, storage guidance and batch requirements with our team before ordering." },
            ],
          },
          {
            title: "Who we serve",
            description: "Our bulk and commercial-grade ingredients are designed for businesses that need reliable, uniform kitchen and production inputs.",
            points: [
              { title: "Food and spice manufacturers", description: "Ingredients for a wide range of food formulations." },
              { title: "Snack producers and seasoning blenders", description: "Onion and garlic flavour for blends and coatings." },
              { title: "Ready-to-eat and ready-to-cook brands", description: "Convenient ingredients for RTE and RTC products." },
              { title: "Hotels, restaurants and cafés", description: "Practical, consistent inputs for HoReCa kitchens." },
            ],
          },
        ].map(({ title, description, points }, i) => (
          <Reveal key={title} delay={i * 0.08}>
            <Leaf className="h-8 w-8 text-secondary" />
            <h2 className="text-3xl mt-4">{title}</h2>
            <p className="mt-3 text-muted-foreground leading-relaxed">{description}</p>
            <ul className="mt-5 space-y-4">
              {points.map((point) => (
                <li key={point.title} className="border-l-2 border-secondary pl-4 text-muted-foreground leading-relaxed">
                  <strong className="text-primary">{point.title}.</strong>{" "}{point.description}
                </li>
              ))}
            </ul>
          </Reveal>
        ))}
      </section>
      <section className="mx-auto max-w-7xl px-5 text-center">
        <Reveal>
          <p className="font-display text-3xl md:text-5xl italic text-accent max-w-3xl mx-auto">"Grown in India. Dried with care. Ready when you are."</p>
          <Link href="/contact" className="mt-10 inline-block rounded-full bg-primary text-primary-foreground px-7 py-4">Talk to our team</Link>
        </Reveal>
      </section>
    </>
  );
}
