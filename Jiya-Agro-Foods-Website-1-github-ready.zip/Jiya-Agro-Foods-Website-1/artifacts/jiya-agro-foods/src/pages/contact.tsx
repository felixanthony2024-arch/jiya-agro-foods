import { useState, type FormEvent } from "react";
import { Phone, Mail, MapPin, MessageCircle, Send } from "lucide-react";
import { products } from "@/data/products";
import { CONTACT, mailLink, usePageMeta, waLink } from "@/lib/site";
import { Eyebrow, Reveal } from "@/components/bits";

export default function Contact() {
  usePageMeta("Contact and Enquiry", "Enquire with Jiya Agro Foods about dehydrated onion and garlic via WhatsApp, email or phone.");
  const initial = new URLSearchParams(window.location.search).get("product") ?? "";
  const [form, setForm] = useState({ name: "", company: "", product: products.some((p) => p.slug === initial) ? initial : "", quantity: "", message: "" });
  const [error, setError] = useState("");
  const [opened, setOpened] = useState("");
  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm({ ...form, [k]: e.target.value });

  const body = () => {
    const prod = products.find((p) => p.slug === form.product)?.name ?? "Not specified";
    return [
      "Hello Jiya Agro Foods, I'd like to enquire.",
      `Name: ${form.name}`,
      form.company && `Company: ${form.company}`,
      `Product: ${prod}`,
      `Quantity: ${form.quantity || "Not specified"}`,
      `Message: ${form.message}`,
    ].filter(Boolean).join("\n");
  };

  function go(channel: "whatsapp" | "email") {
    if (!form.name.trim() || !form.message.trim()) { setError("Please add your name and a short message."); return; }
    setError("");
    const url = channel === "whatsapp" ? waLink(body()) : mailLink(CONTACT.sales, `Product enquiry from ${form.name}`, body());
    window.open(url, channel === "whatsapp" ? "_blank" : "_self", "noopener");
    setOpened(channel === "whatsapp" ? "WhatsApp" : "your email app");
  }

  const field = "w-full rounded-2xl border bg-card px-4 py-3 outline-none focus:ring-2 focus:ring-ring";
  return (
    <div className="mx-auto max-w-7xl px-5 py-16 grid lg:grid-cols-12 gap-12">
      <div className="lg:col-span-5">
        <Reveal>
          <Eyebrow>Enquiry</Eyebrow>
          <h1 className="mt-3 text-5xl md:text-6xl text-primary leading-[0.95]">Let's talk ingredients.</h1>
          <p className="mt-5 text-muted-foreground">Fill in the form and send it through WhatsApp or email. Specifications, MOQ, packaging and pricing are shared on enquiry.</p>
        </Reveal>
        <div className="mt-10 space-y-4">
          {CONTACT.phones.map((p) => (
            <a key={p.tel} href={`tel:${p.tel}`} className="flex items-center gap-4 rounded-2xl border bg-card p-4 hover:border-primary" data-testid={`link-call-${p.tel}`}>
              <Phone className="h-5 w-5 text-accent" /><span className="font-mono">{p.label}</span>
            </a>
          ))}
          <a href={waLink("Hello Jiya Agro Foods")} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 rounded-2xl border bg-card p-4 hover:border-primary"><MessageCircle className="h-5 w-5 text-accent" />WhatsApp +919138002243</a>
          {[CONTACT.sales, CONTACT.info].map((m) => (
            <a key={m} href={`mailto:${m}`} className="flex items-center gap-4 rounded-2xl border bg-card p-4 hover:border-primary"><Mail className="h-5 w-5 text-accent" />{m}</a>
          ))}
          <div className="flex gap-4 rounded-2xl bg-muted p-4"><MapPin className="h-5 w-5 text-accent shrink-0 mt-0.5" /><div><p className="text-xs font-mono uppercase tracking-wider text-muted-foreground">Communication address</p>{CONTACT.address.map((l) => <p key={l}>{l}</p>)}</div></div>
        </div>
      </div>
      <Reveal className="lg:col-span-7" delay={0.1}>
        <form onSubmit={(e: FormEvent) => { e.preventDefault(); go("whatsapp"); }} className="rounded-[2rem] bg-card border p-6 md:p-10 space-y-5 shadow-md" noValidate>
          <div className="grid sm:grid-cols-2 gap-5">
            <label className="block"><span className="text-sm font-medium">Name *</span><input className={`${field} mt-2`} value={form.name} onChange={set("name")} data-testid="input-name" required /></label>
            <label className="block"><span className="text-sm font-medium">Company</span><input className={`${field} mt-2`} value={form.company} onChange={set("company")} data-testid="input-company" /></label>
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            <label className="block"><span className="text-sm font-medium">Product</span>
              <select className={`${field} mt-2`} value={form.product} onChange={set("product")} data-testid="select-product">
                <option value="">Not sure yet</option>
                {products.map((p) => <option key={p.slug} value={p.slug}>{p.name}</option>)}
              </select>
            </label>
            <label className="block"><span className="text-sm font-medium">Approximate quantity</span><input className={`${field} mt-2`} placeholder="e.g. 500 kg per month" value={form.quantity} onChange={set("quantity")} data-testid="input-quantity" /></label>
          </div>
          <label className="block"><span className="text-sm font-medium">Message *</span><textarea rows={5} className={`${field} mt-2`} placeholder="Tell us about your application, preferred form (kibbled, flakes, powder) and packaging needs." value={form.message} onChange={set("message")} data-testid="input-message" required /></label>
          {error && <p role="alert" className="text-destructive text-sm">{error}</p>}
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button type="submit" className="flex-1 rounded-full bg-primary text-primary-foreground px-6 py-4 inline-flex justify-center items-center gap-2" data-testid="button-send-whatsapp"><MessageCircle className="h-4 w-4" /> Open in WhatsApp</button>
            <button type="button" onClick={() => go("email")} className="flex-1 rounded-full bg-accent text-accent-foreground px-6 py-4 inline-flex justify-center items-center gap-2" data-testid="button-send-email"><Send className="h-4 w-4" /> Open email draft</button>
          </div>
          <p className="text-xs text-muted-foreground">Nothing is sent from this website. These buttons open WhatsApp or your email app with your enquiry pre-filled, so you can review and send it yourself.</p>
          {opened && <p className="text-sm rounded-xl bg-secondary/20 p-3" role="status" data-testid="status-opened">We tried to open {opened} with your message. Please press send there to complete your enquiry.</p>}
        </form>
      </Reveal>
    </div>
  );
}
