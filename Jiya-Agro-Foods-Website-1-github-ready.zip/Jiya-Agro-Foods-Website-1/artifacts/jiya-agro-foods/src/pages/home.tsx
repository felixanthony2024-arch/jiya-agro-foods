import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Droplets, Package, Scale, Sprout, Factory, ChefHat, Store, CookingPot } from "lucide-react";
import { products, imgPath } from "@/data/products";
import { usePageMeta, waLink } from "@/lib/site";
import { Reveal, Eyebrow, ProductCard, Leaf } from "@/components/bits";

const USES = ["Soups", "Sauces", "Curries", "Marinades", "Seasonings", "Snacks", "Ready-to-eat foods", "Bakery", "Pizza", "Chutney", "Pickle"];

export default function Home() {
  usePageMeta("Jiya Agro Foods | Dehydrated Onion and Garlic from India", "Indian manufacturer and supplier of dehydrated white and red onion (kibbled, flakes, powder, granules) and garlic flakes and powder for food makers and kitchens.");
  return (
    <>
      {/* COVER */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-5 pt-8 md:pt-14 pb-16 grid md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-12 max-w-3xl mx-auto text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.8 }}>
              <Eyebrow>Agro-processing / INDIA</Eyebrow>
              <h1 className="mt-5 text-5xl md:text-6xl lg:text-7xl leading-[1.05] font-semibold" data-testid="heading-premium-ingredients">
                <span className="text-primary">Premium dehydrated</span>{" "}
                <span className="text-[#876024]">white</span>{" "}
                <span className="text-primary">and</span>{" "}
                <span className="text-accent">red onions</span>
              </h1>
              <p className="mt-6 text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
                Garlic flakes and powders—processed for exceptional flavor retention, uniform quality, and seamless kitchen integration.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                <Link href="/products" data-testid="button-hero-products" className="rounded-full bg-primary text-primary-foreground px-6 py-3.5 inline-flex items-center gap-2 hover:gap-3 transition-all">Browse products <ArrowRight className="h-4 w-4" /></Link>
                <Link href="/contact" data-testid="button-hero-enquire" className="rounded-full border-2 border-primary/20 px-6 py-3.5 hover:border-primary transition-colors">Send an enquiry</Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <div className="bg-secondary text-secondary-foreground py-4 overflow-hidden border-y border-primary/10" aria-hidden>
        <div className="flex w-max animate-marquee gap-10 font-display text-2xl md:text-3xl italic">
          {[...USES, ...USES].map((u, i) => (
            <span key={i} className="flex items-center gap-10">{u}<Leaf className="h-5 w-5 text-primary" /></span>
          ))}
        </div>
      </div>

      {/* PRODUCTS */}
      <section className="mx-auto max-w-7xl px-5 py-24">
        <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
          <Reveal>
            <Eyebrow>The range</Eyebrow>
            <h2 className="mt-3 text-4xl md:text-6xl max-w-2xl">Five staples, <span className="text-accent italic font-normal">one pantry shelf.</span></h2>
          </Reveal>
          <Link href="/products" className="font-mono text-sm underline underline-offset-4 hover:text-accent">View full catalogue</Link>
        </div>
        <div className="grid md:grid-cols-6 gap-5">
          {products.map((p, i) => (
            <Reveal key={p.slug} delay={i * 0.07} className={i < 2 ? "md:col-span-3" : "md:col-span-2"}>
              <ProductCard p={p} big={i < 2} />
            </Reveal>
          ))}
        </div>
        <p className="mt-8 text-muted-foreground">
          Looking for white or red onion granules or kibbled onion?{" "}
          <Link href="/contact" className="font-medium text-primary underline underline-offset-4">Ask our team about grades, sizes and bulk requirements.</Link>
        </p>
      </section>

      {/* FORMS */}
      <section className="bg-primary text-primary-foreground py-24 relative overflow-hidden">
        <Leaf className="absolute -top-10 -right-10 h-72 w-72 text-primary-foreground/5 animate-floaty" />
        <div className="mx-auto max-w-7xl px-5">
          <Reveal>
            <Eyebrow className="!text-secondary">Four forms</Eyebrow>
            <h2 className="mt-3 text-4xl md:text-6xl max-w-3xl">Choose the cut your recipe needs.</h2>
          </Reveal>
          <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-4 gap-px bg-primary-foreground/15 rounded-3xl overflow-hidden">
            {[
              { t: "Kibbled", d: "Chunkier pieces for texture in gravies, ready meals and blends. Available in white and red onion by enquiry.", n: "01" },
              { t: "Flakes", d: "Sliced and dried. Rehydrate in water or let them soften in a simmering dish.", n: "02" },
              { t: "Powder", d: "Finely ground for even blending in seasonings, sauces and snack coatings.", n: "03" },
              { t: "Granules", d: "Granulated white and red onion for recipes that need texture rather than fine powder. Ask our team about grades and sizes.", n: "04" },
            ].map((f, i) => (
              <Reveal key={f.t} delay={i * 0.1} className="bg-primary p-8 md:p-10 h-full">
                <span className="font-mono text-secondary text-sm">{f.n}</span>
                <h3 className="text-4xl mt-6">{f.t}</h3>
                <p className="mt-4 text-primary-foreground/75 leading-relaxed">{f.d}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* STORY BAND */}
      <section className="mx-auto max-w-7xl px-5 py-24 grid md:grid-cols-12 gap-10 items-center">
        <Reveal className="md:col-span-6">
          <div className="rounded-[2rem] overflow-hidden shadow-lg">
            <img src={imgPath("site-banner.jpg")} alt="Red onion beside a bowl spilling dehydrated onion flakes" loading="lazy" className="w-full aspect-[16/14] object-cover" />
          </div>
        </Reveal>
        <Reveal className="md:col-span-6" delay={0.1}>
          <Eyebrow>Why dehydrated</Eyebrow>
          <h2 className="mt-3 text-4xl md:text-5xl">All the character of the bulb. None of the peeling.</h2>
          <div className="mt-8 grid sm:grid-cols-2 gap-6">
            {[
              { i: Sprout, t: "Characteristic flavour", d: "The familiar taste and aroma of onion and garlic." },
              { i: Package, t: "Easy storage", d: "Dry ingredients that are simple to keep and handle." },
              { i: Scale, t: "Consistency", d: "Uniform forms that keep recipes steady." },
              { i: Droplets, t: "Flexible use", d: "Use dry, mix into liquid, or rehydrate flakes." },
            ].map(({ i: I, t, d }) => (
              <div key={t} className="flex gap-4">
                <span className="h-11 w-11 shrink-0 rounded-2xl bg-secondary/30 text-primary grid place-items-center"><I className="h-5 w-5" /></span>
                <div><p className="font-medium">{t}</p><p className="text-sm text-muted-foreground mt-1">{d}</p></div>
              </div>
            ))}
          </div>
          <Link href="/about" className="mt-10 inline-flex items-center gap-2 text-accent font-medium hover:gap-3 transition-all">Read our story <ArrowRight className="h-4 w-4" /></Link>
        </Reveal>
      </section>

      {/* WHO */}
      <section className="bg-muted/60 py-24">
        <div className="mx-auto max-w-7xl px-5">
          <Reveal><h2 className="text-4xl md:text-5xl max-w-2xl">Who we cook for.</h2></Reveal>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { i: Factory, t: "Food manufacturers", d: "Ready-to-eat lines, soups, sauces and snack production." },
              { i: Store, t: "Spice blenders", d: "Powders and flakes for masalas, rubs and seasoning mixes." },
              { i: ChefHat, t: "Restaurants", d: "Quicker prep for gravies, marinades, pizza and chutneys." },
              { i: CookingPot, t: "Everyday cooks", d: "Onion and garlic flavour ready when the pan is hot." },
            ].map(({ i: I, t, d }, k) => (
              <Reveal key={t} delay={k * 0.08} className={`rounded-3xl p-7 h-full ${k % 2 ? "bg-card border" : "bg-accent text-accent-foreground"}`}>
                <I className="h-7 w-7" />
                <h3 className="text-2xl mt-10">{t}</h3>
                <p className={`mt-2 text-[15px] ${k % 2 ? "text-muted-foreground" : "text-accent-foreground/80"}`}>{d}</p>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* GUIDANCE */}
      <section className="mx-auto max-w-7xl px-5 py-24 grid md:grid-cols-2 gap-12">
        <Reveal>
          <Eyebrow>General culinary guidance</Eyebrow>
          <h2 className="mt-3 text-4xl md:text-5xl">A quick field guide to using them.</h2>
          <p className="mt-5 text-muted-foreground max-w-md">General tips only. Adjust to your recipe and taste, and ask us for product-specific information.</p>
        </Reveal>
        <ol className="space-y-6">
          {[
            ["Powders", "Add gradually to taste, or mix into a little liquid first for even dispersion."],
            ["Flakes", "Rehydrate in water until the texture suits you, or simmer directly in a moist dish."],
            ["Onion granules", "Add gradually to moist dishes or rehydrate to suit your recipe. Follow the label and confirm grade-specific guidance with our team."],
            ["Storage", "Keep dry and airtight, away from moisture. Reseal after every use."],
          ].map(([t, d], i) => (
            <Reveal key={t} delay={i * 0.1}>
              <li className="flex gap-6 border-b pb-6">
                <span className="font-display text-5xl text-secondary">{i + 1}</span>
                <div><p className="text-xl font-display">{t}</p><p className="text-muted-foreground mt-1">{d}</p></div>
              </li>
            </Reveal>
          ))}
        </ol>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-5">
        <Reveal className="rounded-[2.5rem] bg-accent text-accent-foreground p-10 md:p-16 grid md:grid-cols-12 gap-8 items-center relative overflow-hidden">
          <Leaf className="absolute -bottom-16 -left-10 h-64 w-64 text-accent-foreground/10" />
          <div className="md:col-span-8 relative">
            <h2 className="text-4xl md:text-6xl">Tell us what you're making.</h2>
            <p className="mt-4 text-accent-foreground/80 max-w-lg">Specifications, MOQ, packaging and pricing are shared on enquiry, tailored to your requirement.</p>
          </div>
          <div className="md:col-span-4 flex flex-col gap-3 relative">
            <Link href="/contact" className="rounded-full bg-background text-foreground px-6 py-4 text-center font-medium hover:-translate-y-0.5 transition-transform">Open enquiry form</Link>
            <a href={waLink("Hello Jiya Agro Foods, I'd like to enquire about your dehydrated onion and garlic products.")} target="_blank" rel="noopener noreferrer"
              className="rounded-full border-2 border-accent-foreground/40 px-6 py-4 text-center hover:bg-accent-foreground/10">Message on WhatsApp</a>
          </div>
        </Reveal>
      </section>
    </>
  );
}
