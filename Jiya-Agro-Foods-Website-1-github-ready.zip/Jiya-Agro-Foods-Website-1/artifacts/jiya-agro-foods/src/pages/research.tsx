import type { ReactElement } from "react";
import { usePageMeta } from "@/lib/site";
import { Eyebrow } from "@/components/bits";
import research from "@/content/research.md?raw";

function inline(t: string) {
  const parts = t.split(/(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))/g);
  return parts.map((s, i) => {
    if (s.startsWith("**")) return <strong key={i}>{s.slice(2, -2)}</strong>;
    const m = s.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (m) return <a key={i} href={m[2]} target="_blank" rel="noopener noreferrer" className="text-accent underline">{m[1]}</a>;
    return s;
  });
}

function Markdown({ src }: { src: string }) {
  const lines = src.split("\n");
  const out: ReactElement[] = [];
  let i = 0;
  while (i < lines.length) {
    const l = lines[i];
    if (l.startsWith("|")) {
      const rows: string[][] = [];
      while (i < lines.length && lines[i].startsWith("|")) {
        if (!/^\|[\s:-|]+\|$/.test(lines[i])) rows.push(lines[i].split("|").slice(1, -1).map((c) => c.trim()));
        i++;
      }
      out.push(
        <div key={i} className="overflow-x-auto my-6 rounded-2xl border"><table className="w-full text-sm">
          <thead className="bg-muted"><tr>{rows[0]?.map((c, k) => <th key={k} className="text-left p-3">{inline(c)}</th>)}</tr></thead>
          <tbody>{rows.slice(1).map((r, k) => <tr key={k} className="border-t">{r.map((c, j) => <td key={j} className="p-3 align-top">{inline(c)}</td>)}</tr>)}</tbody>
        </table></div>);
      continue;
    }
    if (/^#{1,3} /.test(l)) {
      const lvl = l.match(/^#+/)![0].length;
      const txt = l.replace(/^#+ /, "");
      out.push(lvl === 1 ? <h2 key={i} className="text-4xl mt-10">{txt}</h2> : lvl === 2 ? <h3 key={i} className="text-2xl mt-10">{txt}</h3> : <h4 key={i} className="text-lg font-display mt-6">{txt}</h4>);
    } else if (/^[-*] /.test(l)) {
      const items: string[] = [];
      while (i < lines.length && /^[-*] /.test(lines[i])) items.push(lines[i++].slice(2));
      out.push(<ul key={i} className="list-disc pl-6 my-3 space-y-1">{items.map((t, k) => <li key={k}>{inline(t)}</li>)}</ul>);
      continue;
    } else if (l.trim()) out.push(<p key={i} className="my-3 leading-relaxed">{inline(l)}</p>);
    i++;
  }
  return <>{out}</>;
}

export default function Research() {
  usePageMeta("Market Notes", "Internal comparison of five Indian dehydrated onion and garlic supplier websites.");
  return (
    <div className="mx-auto max-w-4xl px-5 py-16">
      <Eyebrow>Internal research</Eyebrow>
      <h1 className="mt-3 text-5xl text-primary">Peer website comparison</h1>
      <p className="mt-3 text-muted-foreground">Five Indian peer websites reviewed for content and structure. For planning reference only.</p>
      <div className="mt-8"><Markdown src={research} /></div>
    </div>
  );
}
