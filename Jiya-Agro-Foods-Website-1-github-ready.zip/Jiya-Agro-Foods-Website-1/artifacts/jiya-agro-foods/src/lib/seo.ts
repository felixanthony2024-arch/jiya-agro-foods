// Use the verified primary publishing domain, never a workspace preview URL.
export const SITE_ORIGIN = "https://jiyaagrofoods.com";

export type PageSeo = { title: string; description: string };

export const SEO_PAGES: Record<string, PageSeo> = {
  "/": {
    title: "Jiya Agro Foods | Dehydrated Onion and Garlic from India",
    description: "Indian manufacturer and supplier of dehydrated white and red onion, onion powder, garlic flakes and garlic powder for food manufacturers and commercial kitchens.",
  },
  "/products": {
    title: "Product Catalogue | Jiya Agro Foods",
    description: "Browse Jiya Agro Foods dehydrated onion powder, garlic powder, red and white onion flakes and garlic flakes.",
  },
  "/about": {
    title: "Our Story | Jiya Agro Foods",
    description: "Meet Jiya Agro Foods, an Indian manufacturer and supplier of premium dehydrated onion and garlic ingredients for food processors and commercial kitchens.",
  },
  "/contact": {
    title: "Contact and Enquiry | Jiya Agro Foods",
    description: "Enquire with Jiya Agro Foods about dehydrated onion and garlic via WhatsApp, email or phone.",
  },
  "/research": {
    title: "Market Notes | Jiya Agro Foods",
    description: "A comparison of five Indian dehydrated onion and garlic supplier websites and the approach behind Jiya's updated website.",
  },
  "/products/onion-powder": {
    title: "Dehydrated Onion Powder | Jiya Agro Foods",
    description: "Explore Jiya Agro Foods dehydrated onion powder: product specifications, moisture information, benefits and uses in seasonings, sauces and commercial food production.",
  },
  "/products/garlic-powder": {
    title: "Dehydrated Garlic Powder | Jiya Agro Foods",
    description: "Discover Jiya Agro Foods garlic powder, with product information, benefits and practical guidance for use in spice blends, marinades and commercial kitchens.",
  },
  "/products/red-onion-flakes": {
    title: "Dehydrated Red Onion Flakes | Jiya Agro Foods",
    description: "Explore dehydrated red onion flakes from Jiya Agro Foods, including product specifications, benefits, applications and rehydration guidance.",
  },
  "/products/garlic-flakes": {
    title: "Dehydrated Garlic Flakes | Jiya Agro Foods",
    description: "Discover Jiya Agro Foods dehydrated garlic flakes for food manufacturers and commercial kitchens. View product specifications, benefits and how-to-use guidance.",
  },
  "/products/white-onion-flakes": {
    title: "Dehydrated White Onion Flakes | Jiya Agro Foods",
    description: "Explore Jiya Agro Foods white onion flakes: product information, specifications, benefits and practical uses in soups, sauces and food production.",
  },
};

export const normalizeSeoPath = (path: string) =>
  path.split(/[?#]/)[0].replace(/\/+$/, "") || "/";

export const canonicalUrl = (path: string) =>
  `${SITE_ORIGIN}${normalizeSeoPath(path) === "/" ? "/" : normalizeSeoPath(path)}`;
