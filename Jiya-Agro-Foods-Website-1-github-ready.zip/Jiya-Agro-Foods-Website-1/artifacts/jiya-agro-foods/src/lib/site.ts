import { useEffect } from "react";
import { useLocation } from "wouter";
import { canonicalUrl, normalizeSeoPath, SEO_PAGES, SITE_ORIGIN } from "./seo";

export const CONTACT = {
  phones: [
    { label: "+919138001617", tel: "+919138001617" },
    { label: "+919138002243", tel: "+919138002243" },
  ],
  whatsapp: "919138002243",
  sales: "sales@jiyaagrofoods.com",
  info: "info@jiyaagrofoods.com",
  address: ["PLOT NO. 15 KH NO. 6/8 UPPER GROUND FLOOR SECTOR 19B, DWARKA, DELHI 110077"],
};

export const SOCIALS = [
  { name: "Facebook", href: "https://www.facebook.com/share/1EzkpRhutP/" },
  { name: "Instagram", href: "https://instagram.com/jiyaagrofoods?dlrf=eHlkdDI2cXJtNDU4" },
  { name: "X", href: "https://x.com/Jiyaagrofoods" },
  { name: "Pinterest", href: "https://pin.it/7wwyXIzme" },
];

export const waLink = (text: string) => `https://wa.me/${CONTACT.whatsapp}?text=${encodeURIComponent(text)}`;
export const mailLink = (to: string, subject: string, body: string) =>
  `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

function setMeta(attr: "name" | "property", key: string, content: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.content = content;
}

export function usePageMeta(title: string, description: string) {
  const [location] = useLocation();
  useEffect(() => {
    const route = normalizeSeoPath(location);
    const page = SEO_PAGES[route];
    const full = page?.title ?? (title.includes("Jiya") ? title : `${title} | Jiya Agro Foods`);
    const summary = page?.description ?? description;
    document.title = full;
    setMeta("name", "description", summary);
    setMeta("property", "og:title", full);
    setMeta("property", "og:description", summary);
    setMeta("name", "twitter:title", full);
    setMeta("name", "twitter:description", summary);
    setMeta("name", "robots", page ? "index, follow" : "noindex, follow");
    setMeta("property", "og:image", `${SITE_ORIGIN}/images/jiya-logo.jpg`);
    setMeta("name", "twitter:image", `${SITE_ORIGIN}/images/jiya-logo.jpg`);
    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (page) {
      if (!canonical) {
        canonical = document.createElement("link");
        canonical.rel = "canonical";
        document.head.appendChild(canonical);
      }
      canonical.href = canonicalUrl(route);
      setMeta("property", "og:url", canonical.href);
    } else {
      canonical?.remove();
      document.head.querySelector('meta[property="og:url"]')?.remove();
    }
    window.scrollTo(0, 0);
  }, [title, description, location]);
}
