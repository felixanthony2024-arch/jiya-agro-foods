import type { ReactNode } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import type { Product } from "@/data/products";

export function Reveal({ children, delay = 0, className = "" }: { children: ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div className={className} initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}>
      {children}
    </motion.div>
  );
}

export function Eyebrow({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <p className={`font-mono text-xs uppercase tracking-[0.22em] text-accent ${className}`}>{children}</p>;
}

export function ProductCard({ p, big = false }: { p: Product; big?: boolean }) {
  return (
    <Link href={`/products/${p.slug}`} data-testid={`card-product-${p.slug}`}
      className="group block rounded-[1.75rem] bg-card border overflow-hidden hover:-translate-y-1 hover:shadow-lg transition-all duration-500 h-full">
      <div className={`relative overflow-hidden bg-[hsl(150_30%_8%)] ${big ? "aspect-[4/3]" : "aspect-square"}`}>
        <img src={p.image} alt={p.name} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700" />
        <span className="absolute top-4 left-4 rounded-full bg-background/90 px-3 py-1 font-mono text-[11px] uppercase tracking-wider">{p.family} / {p.form}</span>
      </div>
      <div className="p-6 flex items-end justify-between gap-4">
        <div>
          <h3 className={`font-display ${big ? "text-3xl" : "text-2xl"} leading-tight`}>{p.short}</h3>
          <p className="text-muted-foreground mt-1 text-[15px]">{p.summary}</p>
        </div>
        <span className="h-11 w-11 shrink-0 rounded-full border grid place-items-center group-hover:bg-primary group-hover:text-primary-foreground transition-colors"><ArrowRight className="h-4 w-4" /></span>
      </div>
    </Link>
  );
}

export function Leaf({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 60 60" className={className} aria-hidden>
      <path d="M8 52C8 24 26 8 54 6c0 28-16 46-46 46z" fill="currentColor" />
      <path d="M10 50C22 36 34 24 50 10" stroke="currentColor" strokeWidth="2.5" strokeOpacity="0.4" fill="none" />
    </svg>
  );
}
