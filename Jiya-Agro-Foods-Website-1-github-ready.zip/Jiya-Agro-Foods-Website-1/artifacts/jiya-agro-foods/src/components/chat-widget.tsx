import { useEffect, useRef, useState } from "react";
import { MessageCircle, X, Send, RotateCcw, Sprout } from "lucide-react";
import { useCustomerChat } from "@workspace/api-client-react";
import { CONTACT, waLink } from "@/lib/site";

type Msg = { role: "user" | "assistant"; content: string };

const GREETING: Msg = {
  role: "assistant",
  content: "Namaste. I'm the Jiya ingredient assistant. Ask me about our onion and garlic flakes and powders, how to use them, or how to send an enquiry.",
};

const STARTERS = [
  "Which product suits a snack seasoning?",
  "How do I rehydrate onion flakes?",
  "Garlic flakes or garlic powder for pickles?",
  "How can I ask for a quote?",
];

export function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([GREETING]);
  const [input, setInput] = useState("");
  const [failed, setFailed] = useState(false);
  const chat = useCustomerChat();
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [msgs, chat.isPending, failed]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  async function run(history: Msg[]) {
    setFailed(false);
    const payload = history.filter((m, i) => !(i === 0 && m === GREETING)).slice(-16).map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));
    try {
      const res = await chat.mutateAsync({ data: { messages: payload } });
      setMsgs([...history, { role: "assistant", content: res.reply }]);
    } catch {
      setFailed(true);
    }
  }

  function send(text: string) {
    const t = text.trim();
    if (!t || chat.isPending) return;
    const next = [...msgs, { role: "user" as const, content: t.slice(0, 2000) }];
    setMsgs(next);
    setInput("");
    run(next);
  }

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        aria-label={open ? "Close ingredient assistant" : "Open ingredient assistant"}
        aria-expanded={open}
        data-testid="button-chat-toggle"
        className="fixed bottom-5 right-5 z-[70] h-16 w-16 rounded-full bg-primary text-primary-foreground shadow-lg grid place-items-center hover:scale-105 transition-transform ring-4 ring-secondary/40"
      >
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </button>
      {open && (
        <section role="dialog" aria-label="Jiya ingredient assistant"
          className="fixed z-[70] bottom-24 right-3 left-3 sm:left-auto sm:right-5 sm:w-[400px] h-[min(620px,calc(100dvh-8rem))] flex flex-col rounded-3xl bg-card border shadow-lg overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-300">
          <header className="bg-primary text-primary-foreground px-5 py-4 flex items-center gap-3">
            <span className="h-10 w-10 rounded-full bg-secondary text-secondary-foreground grid place-items-center"><Sprout className="h-5 w-5" /></span>
            <div>
              <p className="font-display text-lg leading-tight">Ingredient assistant</p>
              <p className="text-xs text-primary-foreground/70">AI answers. Confirm specs and pricing with our team.</p>
            </div>
          </header>
          <div ref={listRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-3" aria-live="polite" data-testid="chat-messages">
            {msgs.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <p className={`max-w-[85%] whitespace-pre-wrap text-[15px] leading-relaxed px-4 py-2.5 rounded-2xl ${m.role === "user" ? "bg-accent text-accent-foreground rounded-br-sm" : "bg-muted rounded-bl-sm"}`}
                  data-testid={`text-chat-${m.role}-${i}`}>{m.content}</p>
              </div>
            ))}
            {msgs.length === 1 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {STARTERS.map((s) => (
                  <button key={s} onClick={() => send(s)} className="text-left text-sm border rounded-full px-3 py-1.5 hover:bg-secondary/25 hover:border-secondary transition-colors" data-testid="button-chat-starter">{s}</button>
                ))}
              </div>
            )}
            {chat.isPending && (
              <div className="flex gap-1.5 px-4 py-3 bg-muted rounded-2xl w-fit" aria-label="Assistant is typing">
                {[0, 1, 2].map((d) => <span key={d} className="h-2 w-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: `${d * 120}ms` }} />)}
              </div>
            )}
            {failed && (
              <div className="rounded-2xl border border-destructive/40 bg-destructive/5 p-3 text-sm space-y-2" role="alert">
                <p>The assistant couldn't reply just now.</p>
                <div className="flex flex-wrap gap-2">
                  <button onClick={() => run(msgs)} className="inline-flex items-center gap-1 rounded-full bg-primary text-primary-foreground px-3 py-1" data-testid="button-chat-retry"><RotateCcw className="h-3.5 w-3.5" /> Retry</button>
                  <a href={waLink("Hello Jiya Agro Foods, I have a question:")} target="_blank" rel="noopener noreferrer" className="rounded-full border px-3 py-1">WhatsApp us</a>
                  <a href={`tel:${CONTACT.phones[0].tel}`} className="rounded-full border px-3 py-1">Call</a>
                </div>
              </div>
            )}
          </div>
          <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="border-t p-3 flex gap-2 items-end">
            <label htmlFor="chat-input" className="sr-only">Your message</label>
            <textarea id="chat-input" ref={inputRef} rows={1} value={input} maxLength={2000}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }}
              placeholder="Ask about onion or garlic..." className="flex-1 resize-none rounded-2xl bg-muted px-4 py-3 text-[15px] outline-none focus:ring-2 focus:ring-ring max-h-32" data-testid="input-chat" />
            <button type="submit" disabled={!input.trim() || chat.isPending} aria-label="Send" className="h-11 w-11 rounded-full bg-accent text-accent-foreground grid place-items-center disabled:opacity-40" data-testid="button-chat-send"><Send className="h-4 w-4" /></button>
          </form>
        </section>
      )}
    </>
  );
}
