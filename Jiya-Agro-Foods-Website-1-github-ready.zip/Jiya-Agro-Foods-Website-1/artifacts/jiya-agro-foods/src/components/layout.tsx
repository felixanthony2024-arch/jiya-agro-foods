import { useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Phone, Mail, MapPin, ArrowUpRight } from "lucide-react";
import type { IconType } from "react-icons";
import { SiFacebook, SiInstagram, SiX, SiPinterest } from "react-icons/si";
import { CONTACT, SOCIALS } from "@/lib/site";
import { imgPath, products } from "@/data/products";
import { ChatWidget } from "@/components/chat-widget";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/products", label: "Products" },
  { href: "/about", label: "Our Story" },
  { href: "/contact", label: "Contact" },
];

const SOCIAL_ICONS: Record<string, IconType> = {
  Facebook: SiFacebook,
  Instagram: SiInstagram,
  X: SiX,
  Pinterest: SiPinterest,
};

export function Logo({ className = "h-12" }: { className?: string }) {
  return <img src={imgPath("jiya-logo.jpg")} alt="Jiya Agro Foods" className={`${className} w-auto rounded-md mix-blend-multiply`} />;
}

export function Layout({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [loc] = useLocation();
  const active = (h: string) => (h === "/" ? loc === "/" : loc.startsWith(h));
  return (
    <div className="min-h-[100dvh] flex flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 z-[80] bg-primary text-primary-foreground px-3 py-2 rounded">Skip to content</a>
      <header className="sticky top-0 z-50 bg-background/85 backdrop-blur-md border-b border-border/70">
        <div className="mx-auto max-w-7xl px-5 h-20 flex items-center justify-between gap-6">
          <Link href="/" data-testid="link-logo" className="shrink-0"><Logo className="h-14" /></Link>
          <nav className="hidden md:flex items-center gap-1" aria-label="Primary">
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} data-testid={`link-nav-${n.label.toLowerCase().replace(/ /g, "-")}`}
                className={`px-4 py-2 rounded-full text-[15px] transition-colors ${active(n.href) ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}>
                {n.label}
              </Link>
            ))}
          </nav>
          <div className="hidden md:flex items-center gap-4">
            <a href={`tel:${CONTACT.phones[0].tel}`} className="text-sm font-mono flex items-center gap-2 hover:text-accent" data-testid="link-header-phone">
              <Phone className="h-4 w-4" /> {CONTACT.phones[0].label}
            </a>
            <Link href="/contact" data-testid="button-header-quote" className="rounded-full bg-accent text-accent-foreground px-5 py-2.5 text-sm font-medium hover:-translate-y-0.5 transition-transform">
              Request a quote
            </Link>
          </div>
          <button className="md:hidden p-2 rounded-full border" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} onClick={() => setOpen(!open)} data-testid="button-menu">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
        {open && (
          <nav className="md:hidden border-t bg-background px-5 py-4 flex flex-col gap-1" aria-label="Mobile">
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} onClick={() => setOpen(false)} className={`px-4 py-3 rounded-xl font-display text-2xl ${active(n.href) ? "bg-primary text-primary-foreground" : ""}`}>{n.label}</Link>
            ))}
            <a href={`tel:${CONTACT.phones[0].tel}`} className="px-4 py-3 font-mono text-sm">{CONTACT.phones[0].label}</a>
          </nav>
        )}
      </header>
      <main id="main" className="flex-1">{children}</main>
      <Footer />
      <ChatWidget />
    </div>
  );
}

function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground mt-24 relative overflow-hidden">
      <div className="mx-auto max-w-7xl px-5 pt-16 pb-8 grid gap-12 md:grid-cols-12">
        <div className="md:col-span-4">
          <div className="bg-[hsl(44_38%_94%)] inline-block rounded-2xl p-3"><Logo className="h-20" /></div>
          <p className="mt-6 text-primary-foreground/80 max-w-xs leading-relaxed">Leading manufacturers and suppliers of high-grade dehydrated onion and garlic, delivering dependable, farm-grade quality to clients nationwide.</p>
        </div>
        <div className="md:col-span-3">
          <h3 className="font-mono text-xs uppercase tracking-[0.2em] text-secondary mb-4">Products</h3>
          <ul className="space-y-2">
            {products.map((p) => (
              <li key={p.slug}><Link href={`/products/${p.slug}`} className="hover:text-secondary">{p.short}</Link></li>
            ))}
          </ul>
        </div>
        <div className="md:col-span-5 space-y-3 text-primary-foreground/90">
          <h3 className="font-mono text-xs uppercase tracking-[0.2em] text-secondary mb-4">Reach us</h3>
          {CONTACT.phones.map((p) => (
            <a key={p.tel} href={`tel:${p.tel}`} className="flex gap-3 items-center hover:text-secondary"><Phone className="h-4 w-4" />{p.label}</a>
          ))}
          <a href={`mailto:${CONTACT.sales}`} className="flex gap-3 items-center hover:text-secondary"><Mail className="h-4 w-4" />{CONTACT.sales}</a>
          <a href={`mailto:${CONTACT.info}`} className="flex gap-3 items-center hover:text-secondary"><Mail className="h-4 w-4" />{CONTACT.info}</a>
          <p className="flex gap-3"><MapPin className="h-4 w-4 mt-1 shrink-0" /><span>Communication Address-<br />Plot no 15 ,KH no 6/8 Upper ground floor Dwarka Sector 19B South West Delhi, Delhi 110077</span></p>
        </div>
      </div>
      <div className="mx-auto max-w-7xl px-5 pb-6">
        <div className="flex flex-wrap gap-2 items-center">
          {SOCIALS.map((s) => {
            const Icon = SOCIAL_ICONS[s.name];
            return (
              <a key={s.name} href={s.href} target="_blank" rel="noopener noreferrer" data-testid={`link-social-${s.name.toLowerCase()}`}
                aria-label={`Jiya Agro Foods on ${s.name} (opens in a new tab)`}
                className="min-h-11 rounded-full border border-primary-foreground/40 px-4 py-2.5 text-sm hover:bg-primary-foreground/10 hover:border-primary-foreground/80 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-secondary focus-visible:ring-offset-2 focus-visible:ring-offset-primary flex items-center gap-2.5">
                <Icon className="h-5 w-5 shrink-0" aria-hidden="true" />
                <span>{s.name}</span>
                <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
              </a>
            );
          })}
        </div>
        <p className="text-xs text-primary-foreground/60 mt-3">Connect with Jiya Agro Foods on social media. Links open in a new tab.</p>
      </div>
      <div className="border-t border-primary-foreground/15">
        <div className="mx-auto max-w-7xl px-5 py-5 flex flex-wrap justify-between gap-3 text-xs text-primary-foreground/60">
          <span>Jiya Agro Foods. Specifications, MOQ, packaging and pricing by enquiry.</span>
          <Link href="/research" className="hover:text-primary-foreground" data-testid="link-research">Market notes</Link>
        </div>
      </div>
    </footer>
  );
}
