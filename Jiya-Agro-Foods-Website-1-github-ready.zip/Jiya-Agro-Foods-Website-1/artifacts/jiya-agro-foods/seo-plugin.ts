import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import type { Plugin } from "vite";
import { canonicalUrl, normalizeSeoPath, SEO_PAGES, SITE_ORIGIN } from "./src/lib/seo";

const escape = (value: string) =>
  value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

function pageHead(html: string, route: string) {
  const metadata = SEO_PAGES[route];
  const put = (pattern: RegExp, tag: string) => {
    html = pattern.test(html) ? html.replace(pattern, tag) : html.replace("</head>", `  ${tag}\n  </head>`);
  };
  const meta = (key: string, value: string, attr = "name") =>
    put(new RegExp(`<meta\\s+${attr}="${key}"[^>]*>`),
      `<meta ${attr}="${key}" content="${escape(value)}" />`);
  if (metadata) {
    html = html.replace(/<title>[\s\S]*?<\/title>/, `<title>${escape(metadata.title)}</title>`);
    meta("description", metadata.description);
    meta("og:title", metadata.title, "property");
    meta("og:description", metadata.description, "property");
    meta("twitter:title", metadata.title);
    meta("twitter:description", metadata.description);
    const url = canonicalUrl(route);
    put(/<link\s+rel="canonical"[^>]*>/, `<link rel="canonical" href="${url}" />`);
    meta("og:url", url, "property");
  } else {
    html = html.replace(/<link\s+rel="canonical"[^>]*>\s*/, "");
    html = html.replace(/<meta\s+property="og:url"[^>]*>\s*/, "");
  }
  meta("robots", metadata ? "index, follow" : "noindex, follow");
  meta("og:image", `${SITE_ORIGIN}/images/jiya-logo.jpg`, "property");
  meta("twitter:image", `${SITE_ORIGIN}/images/jiya-logo.jpg`);
  return html;
}

export function seoPagesPlugin(): Plugin {
  let outputDir = "";
  let building = false;
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>\n` +
    `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
    Object.keys(SEO_PAGES).map(route => `  <url><loc>${canonicalUrl(route)}</loc></url>`).join("\n") +
    `\n</urlset>\n`;
  return {
    name: "jiya-seo-pages",
    configResolved(config) {
      outputDir = path.resolve(config.root, config.build.outDir);
      building = config.command === "build";
    },
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (req.url?.split("?")[0] !== "/sitemap.xml") return next();
        res.setHeader("Content-Type", "application/xml; charset=utf-8");
        res.end(sitemap);
      });
    },
    transformIndexHtml(html, context) {
      // Vite's SPA fallback rewrites path to index.html; originalUrl retains the route.
      const requested = context.originalUrl ?? context.path;
      return pageHead(html, requested === "/index.html" ? "/" : normalizeSeoPath(requested));
    },
    generateBundle() {
      this.emitFile({ type: "asset", fileName: "sitemap.xml", source: sitemap });
    },
    closeBundle() {
      if (!building) return;
      // Route-specific static heads let crawlers see the correct canonical before JS runs.
      const file = path.join(outputDir, "index.html");
      const template = readFileSync(file, "utf8");
      for (const route of Object.keys(SEO_PAGES)) {
        const destination = route === "/" ? file : path.join(outputDir, route.slice(1), "index.html");
        mkdirSync(path.dirname(destination), { recursive: true });
        writeFileSync(destination, pageHead(template, route));
      }
    },
  };
}
