import { Router, type IRouter } from "express";
import { CustomerChatBody, CustomerChatResponse } from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";
import { productKnowledge } from "../lib/product-knowledge";

const router: IRouter = Router();
const limits = new Map<string, { count: number; expires: number }>();
let activeRequests = 0;

router.post("/openai/customer-chat", async (req, res): Promise<void> => {
  const parsed = CustomerChatBody.safeParse(req.body);
  if (!parsed.success || parsed.data.messages.at(-1)?.role !== "user") {
    res.status(400).json({ error: "Send a customer message of up to 2,000 characters." });
    return;
  }
  const now = Date.now();
  for (const [key, value] of limits) if (value.expires < now) limits.delete(key);
  const key = req.ip ?? "unknown";
  const limit = limits.get(key) ?? { count: 0, expires: now + 60_000 };
  if (limit.count >= 10 || activeRequests >= 8) {
    res.setHeader("Retry-After", "60");
    res.status(429).json({ error: "The assistant is busy. Please retry in a minute or contact sales." });
    return;
  }
  limit.count += 1;
  limits.set(key, limit);
  activeRequests += 1;
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 8192,
      messages: [
        { role: "system", content: productKnowledge },
        ...parsed.data.messages,
      ],
    }, { timeout: 45_000 });
    const reply = completion.choices[0]?.message?.content?.trim();
    if (!reply) throw new Error("AI returned an empty response");
    res.json(CustomerChatResponse.parse({ reply }));
  } catch {
    req.log.error("Customer AI request failed");
    res.status(503).json({ error: "The AI assistant is temporarily unavailable. Please retry or contact sales@jiyaagrofoods.com." });
  } finally {
    activeRequests -= 1;
  }
});

export default router;
