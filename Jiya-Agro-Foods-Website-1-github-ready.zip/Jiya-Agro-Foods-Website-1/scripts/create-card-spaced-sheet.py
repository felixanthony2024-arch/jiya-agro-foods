"""Place the card front and reverse together with a small plain gutter."""
from pathlib import Path
import pymupdf

OUT = Path("generated-artifacts/jiya-reference-card")
MM = 72 / 25.4
source = pymupdf.open(OUT / "Jiya-reference-visiting-card-3mm-bleed.pdf")
doc = pymupdf.open()
page = doc.new_page(width=210 * MM, height=297 * MM)

# Each card has 3 mm bleed around a 90 x 50 mm finished card.
# A 10 mm blank gutter remains between the two complete card artworks.
for index, top in enumerate([79, 145]):
    dest = pymupdf.Rect(57 * MM, top * MM, 153 * MM, (top + 56) * MM)
    page.show_pdf_page(dest, source, index)

doc.set_metadata({"title": "Jiya Agro Foods visiting card"})
pdf_path = OUT / "Jiya-visiting-card-spaced.pdf"
doc.save(pdf_path)
page.get_pixmap(matrix=pymupdf.Matrix(2, 2)).save(
    OUT / "Jiya-visiting-card-spaced-preview.png"
)

with pymupdf.open(pdf_path) as check:
    assert len(check) == 1
    text = check[0].get_text().strip()
    assert "R.P SINGH" in text and "Explore our" in text
    assert "CUTTING" not in text.upper()
    assert abs((145 - (79 + 56)) - 10) < 0.01
print("Created one-page A4 card sheet with a 10 mm gutter and no guide marks or labels.")
