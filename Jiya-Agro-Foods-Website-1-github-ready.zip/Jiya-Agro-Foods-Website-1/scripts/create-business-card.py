"""Update the client's preferred 90 x 50 mm visiting-card reference."""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import qrcode

OUT = Path("generated-artifacts/jiya-reference-card")
OUT.mkdir(parents=True, exist_ok=True)
LOGO = "generated-artifacts/jiya-reference-card/Jiya-logo-transparent.png"
FSSAI = "attached_assets/fssai_logo_updated_1792145646880.jpeg"
FONT = Path("generated-artifacts/jiya-modern-visiting-card")
pdfmetrics.registerFont(TTFont("JiyaSans", str(FONT / "WebSans.ttf")))
pdfmetrics.registerFont(TTFont("JiyaBold", str(FONT / "WebBold.ttf")))
pdfmetrics.registerFont(TTFont("JiyaDisplay", str(FONT / "WebDisplay.ttf")))
GREEN, LIME, CREAM = map(HexColor, ["#145739", "#A7CF3B", "#F6F3EB"])
WEBSITE = "https://jiyaagrofoods.com/"
TEAM = [
    ("R.P SINGH", "CEO & Founder", "+919138002243"),
    ("Kuldeep", "Managing Director", "+919138001617"),
    ("Ritik Soni", "Marketing Director", "+918827456521"),
]
W, H = 90 * mm, 50 * mm

def text(c, x, y, s, size=7, color=CREAM, bold=False):
    c.setFillColor(color)
    c.setFont("JiyaBold" if bold else "JiyaSans", size)
    c.drawString(x * mm, y * mm, s)

def front(c, bleed=0):
    c.setFillColor(CREAM)
    c.rect(-bleed, -bleed, W + 2 * bleed, H + 2 * bleed, fill=1, stroke=0)
    c.drawImage(LOGO, 4 * mm, 21 * mm, width=33 * mm, height=24.65 * mm, mask="auto")
    c.setStrokeColor(HexColor("#D6DFCA"))
    c.setLineWidth(.5)
    c.line(41 * mm, 12 * mm, 41 * mm, 44 * mm)
    for y, (name, role, phone) in zip([41.0, 29.7, 18.4], TEAM):
        text(c, 46, y, name, 8.0, GREEN, bold=True)
        text(c, 46, y - 3.2, role, 5.6, GREEN)
        text(c, 46, y - 6.6, phone, 6.5, GREEN)
        c.linkURL("tel:" + phone, (46 * mm, (y - 7.3) * mm,
                                   85 * mm, (y - 4.3) * mm))
    for y in [31.9, 20.6]:
        c.setStrokeColor(HexColor("#DFE4D7"))
        c.setLineWidth(.35)
        c.line(46 * mm, y * mm, 84 * mm, y * mm)
    c.setFillColor(GREEN)
    c.rect(-bleed, -bleed, W + 2 * bleed, 8 * mm + bleed, fill=1, stroke=0)
    c.setFillColor(LIME)
    c.rect(-bleed, 8 * mm, W + 2 * bleed, .45 * mm, fill=1, stroke=0)
    c.setFont("JiyaSans", 7.0)
    c.setFillColor(CREAM)
    c.drawCentredString(W / 2, 3.2 * mm, "Dehydrated Onion Garlic & Other Vegetables")
    for y, email in [(16.2, "sales@jiyaagrofoods.com"), (12.8, "info@jiyaagrofoods.com")]:
        c.setFillColor(GREEN)
        c.setFont("JiyaSans", 5.5)
        c.drawCentredString(20.5 * mm, y * mm, email)
        c.linkURL("mailto:" + email, (4 * mm, (y - .5) * mm, 37 * mm, (y + 2) * mm))

def qr(c, x, y, size):
    code = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, border=4)
    code.add_data(WEBSITE)
    code.make(fit=True)
    code.make_image(fill_color="#145739", back_color="#F6F3EB").save(
        OUT / "Jiya-new-website-QR.png"
    )
    matrix = code.get_matrix()
    unit = size * mm / len(matrix)
    c.setFillColor(CREAM)
    c.rect(x * mm, y * mm, size * mm, size * mm, stroke=0, fill=1)
    c.setFillColor(GREEN)
    for row, entries in enumerate(matrix):
        for col, dark in enumerate(entries):
            if dark:
                c.rect(x * mm + col * unit, y * mm + (len(matrix) - row - 1) * unit,
                       unit, unit, stroke=0, fill=1)

def back(c, bleed=0):
    c.setFillColor(GREEN)
    c.rect(-bleed, -bleed, W + 2 * bleed, H + 2 * bleed, fill=1, stroke=0)
    # A restrained botanical outline echoes the leaves in the supplied logo.
    c.setStrokeColor(HexColor("#28664A"))
    c.setLineWidth(.55)
    leaf = c.beginPath()
    leaf.moveTo(30 * mm, 17 * mm)
    leaf.curveTo(29 * mm, 36 * mm, 40 * mm, 47 * mm, 59 * mm, 49 * mm)
    leaf.curveTo(58 * mm, 30 * mm, 46 * mm, 18 * mm, 30 * mm, 17 * mm)
    c.drawPath(leaf)
    c.line(30 * mm, 17 * mm, 54 * mm, 44 * mm)
    c.setFillColor(CREAM)
    c.rect(61 * mm, -bleed, 29 * mm + bleed, H + 2 * bleed, fill=1, stroke=0)
    c.setFillColor(LIME)
    c.rect(60.4 * mm, -bleed, .6 * mm, H + 2 * bleed, fill=1, stroke=0)
    text(c, 5, 41, "JIYA AGRO FOODS", 10, bold=True)
    text(c, 5, 37, "DEHYDRATED FOOD INGREDIENTS", 5.2, LIME)
    c.setFillColor(CREAM)
    c.setFont("JiyaDisplay", 15)
    c.drawString(5 * mm, 28 * mm, "Explore our")
    c.drawString(5 * mm, 21.7 * mm, "ingredients.")
    text(c, 5, 16.4, "jiyaagrofoods.com", 7.0, LIME, bold=True)
    c.drawImage(FSSAI, 65 * mm, 37 * mm, width=21 * mm, height=11.5 * mm)
    qr(c, 64.5, 12.5, 22)
    text(c, 67.0, 9.5, "SCAN TO EXPLORE", 5.0, GREEN, bold=True)
    text(c, 5, 11, "COMMUNICATION ADDRESS", 4.5, LIME)
    text(c, 5, 8, "Plot no 15 ,KH no 6/8 Upper ground floor", 5.2)
    text(c, 5, 5.3, "Dwarka Sector 19B South West Delhi,", 5.2)
    text(c, 5, 2.6, "Delhi 110077", 5.2)
    c.linkURL(WEBSITE, (5 * mm, 15 * mm, 40 * mm, 19 * mm))
    c.linkURL(WEBSITE, (64.5 * mm, 12.5 * mm, 86.5 * mm, 34.5 * mm))

def export(name, with_bleed=False):
    b = 3 * mm if with_bleed else 0
    c = canvas.Canvas(str(OUT / name), pagesize=(W + 2*b, H + 2*b))
    c.setTitle("Jiya Agro Foods — client-reference visiting card")
    c.setAuthor("Jiya Agro Foods")
    for draw in [front, back]:
        if with_bleed:
            c.setTrimBox((b, b, W+b, H+b))
            c.setBleedBox((0, 0, W+2*b, H+2*b))
        c.saveState()
        c.translate(b, b)
        draw(c, b)
        c.restoreState()
        c.showPage()
    c.save()

export("Jiya-reference-visiting-card.pdf")
export("Jiya-reference-visiting-card-3mm-bleed.pdf", True)
print("Generated 90 × 50 mm two-page card PDFs.")
