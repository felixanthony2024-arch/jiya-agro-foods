"""Create a double-sided 90 x 55 mm Jiya team card with vector text and QR."""
from pathlib import Path
import urllib.request

import qrcode
from PIL import Image, ImageDraw, ImageFont
from reportlab.lib.colors import HexColor
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas


OUT = Path("generated-artifacts/jiya-modern-visiting-card")
OUT.mkdir(parents=True, exist_ok=True)
LOGO = Path("attached_assets/JIYA_AGRO_FOODS_logo_2K_20261014012257_1792144344211.jpg")
FSSAI = Path("attached_assets/fssai_logo_updated_1792144336736.jpeg")
FONT_DIR = Path("/usr/share/fonts/truetype/dejavu")
pdfmetrics.registerFont(TTFont("CardSans", str(FONT_DIR / "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("CardBold", str(FONT_DIR / "DejaVuSans-Bold.ttf")))

# Embed the same display and body fonts used by the live website.
FONTS = {
    "WebSans": "https://fonts.gstatic.com/s/bricolagegrotesque/v9/3y9U6as8bTXq_nANBjzKo3IeZx8z6up5BeSl5jBNz_19PpbJMXuECpwUxJBOm_OJWiaaD30YfKfjZZoLvRviyM0.ttf",
    "WebBold": "https://fonts.gstatic.com/s/bricolagegrotesque/v9/3y9U6as8bTXq_nANBjzKo3IeZx8z6up5BeSl5jBNz_19PpbJMXuECpwUxJBOm_OJWiaaD30YfKfjZZoLvfzlyM0.ttf",
    "WebDisplay": "https://fonts.gstatic.com/s/fraunces/v38/6NUh8FyLNQOQZAnv9bYEvDiIdE9Ea92uemAk_WBq8U_9v0c2Wa0K7iN7hzFUPJH58njr1603gg7S2nfgRYIcaRyjDg.ttf",
}
for name, url in FONTS.items():
    target = OUT / f"{name}.ttf"
    if not target.exists():
        with urllib.request.urlopen(url, timeout=30) as response:
            target.write_bytes(response.read())
    pdfmetrics.registerFont(TTFont(name, str(target)))

W, H = 90 * mm, 55 * mm
GREEN = HexColor("#1A613D")
INK = HexColor("#122B1F")
BERRY = HexColor("#932F57")
CREAM = HexColor("#F6F2EA")
WHITE = HexColor("#FFFFFF")
MUTED = HexColor("#637269")
RULE = HexColor("#D5DED4")
URL = "https://jiyaagrofoods.com/"
TAGLINE = "Dehydrated Onion Garlic & Other Vegetables"
TEAM = [
    ("R.P SINGH", "CEO & Founder", "+919138002243"),
    ("Kuldeep", "Managing Director", "+919138001617"),
    ("Ritik Soni", "Marketing Director", "+918827456521"),
]
ADDRESS = [
    "Plot no 15 ,KH no 6/8 Upper ground floor",
    "Dwarka Sector 19B South West Delhi,Delhi 110077",
]

code = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, border=4)
code.add_data(URL)
code.make(fit=True)
code.make_image(fill_color="black", back_color="white").save(OUT / "Jiya-website-QR.png")
MATRIX = code.get_matrix()


def text(c, x, y, value, size=7, color=INK, bold=False, align="left", display=False):
    c.setFillColor(color)
    c.setFont("WebDisplay" if display else "WebBold" if bold else "WebSans", size)
    fn = {"left": c.drawString, "center": c.drawCentredString, "right": c.drawRightString}[align]
    fn(x * mm, y * mm, value)


def background(c, color, bleed):
    c.setFillColor(color)
    c.rect(-bleed, -bleed, W + 2 * bleed, H + 2 * bleed, fill=1, stroke=0)


def qr(c, x, y, size):
    module = size * mm / len(MATRIX)
    c.setFillColor(WHITE)
    c.rect(x * mm, y * mm, size * mm, size * mm, fill=1, stroke=0)
    c.setFillColor(INK)
    for row, cells in enumerate(MATRIX):
        for col, dark in enumerate(cells):
            if dark:
                c.rect(
                    x * mm + col * module,
                    y * mm + (len(MATRIX) - row - 1) * module,
                    module, module, fill=1, stroke=0,
                )
    c.linkURL(URL, (x * mm, y * mm, (x + size) * mm, (y + size) * mm))


def front(c, bleed):
    background(c, CREAM, bleed)
    c.setFillColor(GREEN)
    c.rect(49 * mm, -bleed, 41 * mm + bleed, H + 2 * bleed, fill=1, stroke=0)
    # Keep the uploaded logo intact inside a softly rounded photo frame.
    logo = Image.open(LOGO)
    width = 42
    height = width * logo.height / logo.width
    c.saveState()
    path = c.beginPath()
    path.roundRect(3.5 * mm, 17 * mm, width * mm, height * mm, 2.5 * mm)
    c.clipPath(path, stroke=0, fill=0)
    c.drawImage(str(LOGO), 3.5 * mm, 17 * mm,
                width=width * mm, height=height * mm)
    c.restoreState()
    c.setFillColor(BERRY)
    c.roundRect(5 * mm, 11.7 * mm, 9 * mm, .8 * mm, .4 * mm, fill=1, stroke=0)
    text(c, 5, 6.4, "jiyaagrofoods.com", 7.6, GREEN)
    c.linkURL(URL, (5 * mm, 5 * mm, 43 * mm, 10 * mm))
    text(c, 54, 46.5, "JIYA AGRO FOODS", 5.7, CREAM, True)
    c.setFillColor(BERRY)
    c.roundRect(54 * mm, 42.8 * mm, 7 * mm, .8 * mm, .4 * mm, fill=1, stroke=0)
    for y, line in [(35.8, "Dehydrated"), (28.8, "Onion Garlic"),
                    (21.8, "& Other"), (14.8, "Vegetables")]:
        text(c, 54, y, line, 13.5, CREAM, display=True)


def back(c, bleed):
    background(c, CREAM, bleed)
    text(c, 5, 49.5, "JIYA AGRO FOODS  /  CONTACTS", 5.4, GREEN, True)
    c.setFillColor(BERRY)
    c.circle(59.8 * mm, 50.1 * mm, .7 * mm, fill=1, stroke=0)
    c.setFillColor(GREEN)
    c.rect(-bleed, -bleed, W + 2 * bleed, .65 * mm + bleed, fill=1, stroke=0)
    c.setStrokeColor(RULE)
    c.setLineWidth(.45)
    c.line(62.5 * mm, 17 * mm, 62.5 * mm, 46 * mm)
    for y, (name, title, phone) in zip([42.9, 32.3, 21.7], TEAM):
        text(c, 5, y, name, 11.6, GREEN, display=True)
        text(c, 5, y - 3.4, title, 6.0, MUTED)
        text(c, 60, y - 3.4, phone, 7.6, INK, align="right")
        c.linkURL("tel:" + phone, (35 * mm, (y - 4.6) * mm,
                                   61 * mm, (y - 1.8) * mm))
    # Contain the complete FSSAI upload; do not add an unprovided licence number.
    image = Image.open(FSSAI)
    fw = 21
    fh = fw * image.height / image.width
    c.drawImage(str(FSSAI), 65 * mm, 42 * mm, width=fw * mm, height=fh * mm)
    qr(c, 65, 20, 21)
    text(c, 75.5, 18.1, "SCAN TO EXPLORE", 4.8, BERRY, True, "center")
    c.setStrokeColor(RULE)
    c.line(5 * mm, 14.9 * mm, 85 * mm, 14.9 * mm)
    text(c, 5, 12.0, "COMMUNICATION ADDRESS", 4.7, BERRY, True)
    text(c, 5, 8.9, ADDRESS[0], 6.2, INK)
    text(c, 5, 5.8, ADDRESS[1], 6.2, INK)
    text(c, 85, 3.0, "jiyaagrofoods.com", 5.8, GREEN, True, "right")
    c.linkURL(URL, (57 * mm, 1.8 * mm, 85 * mm, 5 * mm))


def export(filename, with_bleed=False):
    b = 3 * mm if with_bleed else 0
    c = canvas.Canvas(str(OUT / filename), pagesize=(W + 2 * b, H + 2 * b))
    c.setTitle("Jiya Agro Foods — modern visiting card")
    c.setAuthor("Jiya Agro Foods")
    c.setSubject("Front and reverse; 90 x 55 mm; website QR and three team contacts")
    for draw in (front, back):
        c.setTrimBox((b, b, W + b, H + b))
        c.setBleedBox((0, 0, W + 2 * b, H + 2 * b))
        c.saveState()
        c.translate(b, b)
        draw(c, b)
        c.restoreState()
        c.showPage()
    c.save()


if __name__ == "__main__":
    export("Jiya-modern-visiting-card.pdf")
    export("Jiya-modern-visiting-card-3mm-bleed.pdf", with_bleed=True)
    print("Created front/reverse PDFs, 90 x 55 mm, plus 3 mm bleed and QR.")
