"""Place the unchanged card sides on A4 with bleed, a gutter and trim marks."""
from pathlib import Path
import pymupdf

OUT = Path("generated-artifacts/jiya-reference-card")
MM = 72 / 25.4
source = pymupdf.open(OUT / "Jiya-reference-visiting-card-3mm-bleed.pdf")
doc = pymupdf.open()
page = doc.new_page(width=210 * MM, height=297 * MM)
green = (.078, .341, .224)
page.insert_text((20 * MM, 22 * MM), "JIYA AGRO FOODS | CUTTING LAYOUT",
                 fontsize=12, fontname="hebo", color=green)
page.insert_text((20 * MM, 29 * MM),
                 "Print at 100% / Actual size. Do not use Fit to page.", fontsize=9)
page.insert_text((20 * MM, 35 * MM),
                 "Finished card: 90 x 50 mm | Bleed: 3 mm | Clear gap: 12 mm",
                 fontsize=8)

for index, top in enumerate([55, 123]):
    page.insert_text((57 * MM, (top - 6) * MM),
                     "FRONT" if index == 0 else "REVERSE", fontsize=8, color=green)
    # Source includes 3 mm bleed on every side. A 12 mm gutter separates artworks.
    dest = pymupdf.Rect(57 * MM, top * MM, 153 * MM, (top + 56) * MM)
    page.show_pdf_page(dest, source, index)
    
page.insert_text((20 * MM, 199 * MM),
                 "Print at 100% / Actual size. The colour extends 3 mm beyond each card edge.",
                 fontsize=8)
page.insert_text((20 * MM, 205 * MM),
                 "Front and reverse are shown separately on this sheet (not duplex-aligned).",
                 fontsize=8)
doc.set_metadata({"title": "Jiya Agro Foods - A4 cutting layout"})
doc.save(OUT / "Jiya-visiting-card-A4-cutting-layout.pdf")
page.get_pixmap(matrix=pymupdf.Matrix(1.5, 1.5)).save(
    OUT / "Jiya-visiting-card-A4-cutting-preview.png"
)
assert abs(page.rect.width / MM - 210) < .01
assert abs((123 - (55 + 56)) - 12) < .01
print("Created A4 cutting sheet: 12 mm gutter, 3 mm bleed, 90 x 50 mm trim.")
