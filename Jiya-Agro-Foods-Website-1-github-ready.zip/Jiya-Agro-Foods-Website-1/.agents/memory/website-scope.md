---
name: Website scope
description: Source boundaries and business positioning for the Jiya website redesign
---

The user requested an updated version of the existing Jiya Agro Foods website, using its products and descriptions alongside uploaded branding and pictures. Peer businesses are comparison references, not sources of Jiya certifications, capabilities or inventory.

**Why:** The user explicitly asked to take information according to the current website while comparing five businesses in the same industry.

**How to apply:** Keep future content changes grounded in Jiya's own confirmed information. Do not expand its range or copy competitor certifications without business confirmation.

Owner-supplied company copy and specifications may extend the information on the original website; do not treat the old website as the only approved source.

**Why:** The user supplied product specifications and replacement company copy directly for the redesigned website.

**How to apply:** Preserve owner-confirmed information when refining the wording, while avoiding unsupported numerical guarantees, certifications or customer endorsements.
