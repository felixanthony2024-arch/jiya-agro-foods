"""Inspect the uploaded client reference visually before editing its layout."""
from pathlib import Path
import fitz

source = Path("attached_assets/Jiya-business-card_2_1792145575158.pdf")
output = Path("generated-artifacts/jiya-client-reference")
output.mkdir(parents=True, exist_ok=True)
with fitz.open(source) as document:
    for index, page in enumerate(document):
        page.get_pixmap(matrix=fitz.Matrix(4, 4)).save(output / f"reference-{index + 1}.png")
        print(f"Page {index + 1}: {page.rect}")
