# Jiya Agro Foods

A responsive product website for Jiya Agro Foods with ingredient discovery, practical usage guides, enquiries and an AI customer assistant.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server via its managed workflow
- `pnpm --filter @workspace/jiya-agro-foods run dev` — website, via its managed workflow
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/jiya-agro-foods` — website, product content, photographs and peer comparison
- `artifacts/api-server/src/lib/product-knowledge.ts` — verified company context for AI
- `lib/api-spec/openapi.yaml` — API contract

## Architecture decisions

- Enquiries open customer-reviewed WhatsApp messages or email drafts; the website does not claim to send messages.
- Chat is stateless and does not retain customer conversations server-side.
- OpenAI access uses Replit AI Integrations; keys remain server-side.

## Product

Search/filter five core products, view product benefits and general culinary guidance, read the company story, prepare sales enquiries and ask an AI ingredient assistant. Market notes compare five relevant Indian peers, without asserting an independently verified top-five ranking.

## User preferences

Use the uploaded JIYA logo prominently as a cover visual.

## Gotchas

- Prices, MOQ, certifications and batch-specific requirements need business confirmation. Supplied typical specifications are not independent lab results or batch guarantees.
- The source website's WhatsApp link omits the country code; the displayed Indian number is used with +91.
- Oct 13 uploaded images are reference screenshots, not standalone product photographs.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
