import './home.css';
import { ArrowDown, ArrowRight, ArrowUpRight, Leaf, PackageCheck, Phone, Sprout } from 'lucide-react';
import { ChatWidget } from '@/components/chat-widget';
import { ProductFeature } from '@/components/product-feature';
import { SiteHeader } from '@/components/site-header';

const range = [
  { name: 'White onion flakes', image: '/products/white-onion-flakes.jpg', alt: 'Dehydrated white onion flakes', tag: 'ONION' },
  { name: 'Red onion flakes', image: '/products/red-onion-flakes.jpg', alt: 'Dehydrated red onion flakes', tag: 'ONION' },
  { name: 'Garlic flakes', image: '/products/garlic-flakes.jpg', alt: 'Dehydrated garlic flakes', tag: 'GARLIC' },
];

export default function HomePage() {
  return (
    <main className="site-shell" id="top">
      <SiteHeader />

      <section className="hero-section">
        <div className="page-wrap hero-grid">
          <div className="hero-copy">
            <div className="eyebrow reveal">From Indian harvests to food makers</div>
            <h1 className="hero-title reveal reveal-delay-1">Good ingredients.<br /><em>Made useful.</em></h1>
            <p className="hero-lede reveal reveal-delay-2">Dehydrated onion and garlic ingredients for kitchens that need dependable flavour, easier handling, and a supply partner who understands the work.</p>
            <div className="hero-actions reveal reveal-delay-2">
              <a className="button-primary" href="#range" data-testid="link-explore-range">Explore our range <ArrowDown size={16} /></a>
              <a className="hero-phone" href="tel:+919138001617" data-testid="link-hero-call"><span><Phone size={15} /></span><span><small>Speak with our team</small><strong>+91 91380 01617</strong></span></a>
            </div>
            <div className="hero-footnote"><span className="footnote-rule" /> Haryana-rooted. Serving food makers across India.</div>
          </div>
          <div className="hero-art">
            <div className="hero-art-backdrop" />
            <div className="hero-image-wrap"><img src="/products/ingredient-spread.jpg" alt="Dehydrated onion and garlic flakes with fresh onion and garlic" data-testid="img-ingredient-spread" /></div>
            <div className="hero-art-note"><span className="note-leaf"><Leaf size={18} /></span><span>Rooted in produce.<br /><b>Ready for production.</b></span></div>
            <div className="hero-stamp"><span>INGREDIENTS</span><strong>01</strong><span>WITH PURPOSE</span></div>
            <div className="hero-side-caption">ONION · GARLIC · DEHYDRATED</div>
          </div>
        </div>
        <div className="hero-bottom-bar"><div className="page-wrap hero-bottom-inner"><span>FLAVOUR, WITHOUT THE FUSS</span><span className="bottom-line" /><span>PRODUCTS FOR PROCESSORS & CULINARY TEAMS</span></div></div>
      </section>

      <section className="intro-band" id="approach">
        <div className="page-wrap intro-grid">
          <div className="intro-label"><span className="eyebrow">The Jiya approach</span><span className="intro-index">01 — 03</span></div>
          <div className="intro-statement"><h2>One less thing to prep.<br /><span>One more thing to count on.</span></h2><p>We connect India's agricultural produce with modern food processing—turning familiar ingredients into practical formats for the people who make food every day.</p></div>
          <div className="intro-aside"><div className="aside-mark"><Sprout size={25} /></div><p>Grounded in agriculture.<br />Made for real-world production.</p><a href="#contact" data-testid="link-approach-contact">Get to know us <ArrowUpRight size={15} /></a></div>
        </div>
      </section>

      <section className="range-section" id="range">
        <div className="page-wrap">
          <div className="section-heading range-heading">
            <div><span className="eyebrow">A focused ingredient range</span><h2 className="section-title">The everyday<br /><i>essentials.</i></h2></div>
            <p>Core allium ingredients in powder and flake form. Choose a format that fits the way your team prepares, blends, and produces.</p>
          </div>
          <div className="powder-range">
            <a href="#onion-powder" className="powder-tile powder-tile-onion" data-testid="link-range-onion-powder">
              <span className="tile-number">01 / POWDER</span><span className="powder-tile-img"><img src="/products/dehydrated-onion-powder.jpg" alt="Dehydrated onion powder" loading="lazy" /></span>
              <span className="tile-bottom"><span><strong>Onion powder</strong><small>Full-bodied, familiar onion flavour</small></span><ArrowUpRight size={19} /></span>
            </a>
            <a href="#garlic-powder" className="powder-tile powder-tile-garlic" data-testid="link-range-garlic-powder">
              <span className="tile-number">02 / POWDER</span><span className="powder-tile-img"><img src="/products/dehydrated-garlic-powder.jpg" alt="Dehydrated garlic powder" loading="lazy" /></span>
              <span className="tile-bottom"><span><strong>Garlic powder</strong><small>Aromatic garlic, ready to blend</small></span><ArrowUpRight size={19} /></span>
            </a>
            <div className="powder-range-note"><div className="note-rule" /><p>Simple ingredients.<br /><strong>Practical formats.</strong></p><span>SELECT WHAT WORKS FOR YOUR PROCESS</span></div>
          </div>
        </div>
      </section>

      <section className="product-details">
        <div className="page-wrap">
          <ProductFeature
            id="onion-powder" number="01" name="Dehydrated Onion Powder" descriptor="A familiar savoury base, ready when you are."
            image="/products/dehydrated-onion-powder.jpg" imageAlt="Dehydrated onion powder in a white bowl" tint="onion"
            intro="Bring the rounded flavour of onion into a blend, seasoning, or prepared food without peeling, chopping, or sautéing on the line."
            highlights={['Convenient to measure, blend, and store', 'Consistent onion flavour and aroma', 'A dependable option for repeat production']}
            applications="Use in spice blends, savoury seasonings, soups, sauces, marinades, snack coatings, and convenience foods."
            note="Also available as red and white onion flakes."
          />
          <div className="product-divider"><span>GOOD FORM, GOOD FUNCTION</span><i /><Leaf size={17} /><i /><span>MADE FOR THE WAY YOU WORK</span></div>
          <ProductFeature
            id="garlic-powder" number="02" name="Dehydrated Garlic Powder" descriptor="Garlic character. A format that gets to work."
            image="/products/dehydrated-garlic-powder.jpg" imageAlt="Dehydrated garlic powder in a white bowl" tint="garlic"
            intro="A straightforward way to bring garlic aroma and flavour into dry mixes and prepared foods, with an ingredient that is easy to handle."
            highlights={['Ready to incorporate into recipes and blends', 'Consistent flavour and aroma from batch to batch', 'Convenient for kitchen and manufacturing workflows']}
            applications="Use in seasonings, sauces, marinades, savoury snacks, soups, ready-to-cook mixes, and prepared foods."
            note="Available in powder and flake formats."
          />
        </div>
      </section>

      <section className="flake-section">
        <div className="page-wrap">
          <div className="flake-intro"><span className="eyebrow">More ways to work with alliums</span><h2 className="section-title">Keep the texture.<br /><i>Keep the character.</i></h2><p>Add onion and garlic flakes to soups, sauces, fillings, and seasoning mixes. Let moisture soften them in the recipe, or rehydrate to suit the texture you need.</p></div>
          <div className="flake-grid">
            {range.map((product, index) => (
              <article className={`flake-card flake-card-${index}`} key={product.name} data-testid={`card-product-${index}`}>
                <div className="flake-image"><img src={product.image} alt={product.alt} loading="lazy" /><span>{product.tag} / FLAKES</span></div>
                <div className="flake-card-copy"><div><small>0{index + 3}</small><h3>{product.name}</h3></div><ArrowUpRight size={17} /></div>
              </article>
            ))}
            <div className="flake-cta"><div className="flake-cta-mark"><PackageCheck size={25} /></div><p>Not sure which format fits?</p><span>Tell us about your application and our team can help you explore the range.</span><a href="#contact" data-testid="link-flake-enquiry">Talk it through <ArrowRight size={16} /></a></div>
          </div>
        </div>
      </section>

      <section className="applications-section" id="applications">
        <div className="page-wrap applications-grid">
          <div className="applications-art"><img src="/products/ingredient-spread.jpg" alt="A spread of onion and garlic ingredients" loading="lazy" /><span>INGREDIENTS FOR EVERYDAY MAKING</span></div>
          <div className="applications-copy"><span className="eyebrow">From a pinch to a production run</span><h2 className="section-title">A little less<br /><i>prep in the process.</i></h2><p>Powders and flakes make familiar onion and garlic easier to work into food production. They are ready to measure and incorporate—so teams can focus on the recipe and the finished food.</p>
            <div className="application-list">
              <div><span className="application-count">01</span><span><strong>Seasoning & spice blends</strong><small>Disperse flavour across dry mixes and coatings.</small></span></div>
              <div><span className="application-count">02</span><span><strong>Sauces, soups & marinades</strong><small>Build an onion or garlic note into savoury bases.</small></span></div>
              <div><span className="application-count">03</span><span><strong>Snacks & prepared foods</strong><small>Bring convenient allium flavour to finished products.</small></span></div>
            </div>
            <a className="text-link" href="#contact" data-testid="link-applications-contact">Discuss your application <ArrowRight size={16} /></a>
          </div>
        </div>
      </section>

      <section className="supply-section">
        <div className="page-wrap supply-inner">
          <div className="supply-top"><span className="eyebrow">A partner in the supply chain</span><span className="supply-index">JIYA / INDIA</span></div>
          <div className="supply-main"><h2 className="section-title">Agriculture at our roots.<br /><i>Food makers in our sights.</i></h2><p>Jiya Agro Foods is an India-based agro-processor with roots in Haryana. We bring agricultural produce closer to the needs of modern food processing—with an emphasis on ingredients that are useful, consistent in character, and supported by a dependable supply relationship.</p></div>
          <div className="supply-bottom"><span><Leaf size={18} /> ROOTED IN INDIA'S AGRICULTURAL LANDSCAPE</span><span>PRODUCTS THAT MAKE SENSE ON THE LINE <ArrowUpRight size={15} /></span></div>
        </div>
      </section>

      <section className="contact-section" id="contact">
        <div className="page-wrap contact-grid">
          <div className="contact-copy"><span className="eyebrow">Let's talk ingredients</span><h2 className="section-title">What are you<br /><i>making next?</i></h2><p>Tell us what your kitchen or production line needs. Reach our team by phone, WhatsApp, or email and start a practical conversation.</p>
            <div className="contact-actions">
              <a href="tel:+919138001617" className="contact-action" data-testid="link-contact-phone"><span className="contact-icon"><Phone size={17} /></span><span><small>CALL OUR TEAM</small><strong>+91 91380 01617</strong></span><ArrowUpRight size={17} /></a>
              <a href="https://wa.me/919138002243" target="_blank" rel="noreferrer" className="contact-action" data-testid="link-contact-whatsapp"><span className="contact-icon whatsapp-icon">W</span><span><small>MESSAGE ON WHATSAPP</small><strong>+91 91380 02243</strong></span><ArrowUpRight size={17} /></a>
              <a href="mailto:sales@jiyaagrofoods.com" className="contact-action" data-testid="link-contact-email"><span className="contact-icon">@</span><span><small>WRITE TO SALES</small><strong>sales@jiyaagrofoods.com</strong></span><ArrowUpRight size={17} /></a>
            </div>
          </div>
          <div className="contact-address">
            <div className="address-kicker"><span>COME FIND US</span><span>DELHI · INDIA</span></div>
             <div className="address-art"><div className="address-orbit orbit-one" /><div className="address-orbit orbit-two" /><span className="address-pin"><Sprout size={27} /></span><div className="address-coordinates">DWARKA<br />DELHI</div></div>
            <span className="address-label">OUR OFFICE</span>
            <address>Building No-75 Ground Floor,<br />Lane no 4 Sai Enclave,<br />Sector 23 Dwarka,<br />Delhi -110077</address>
            <a href="https://maps.google.com/?q=Building+No-75+Ground+Floor+Lane+no+4+Sai+Enclave+Sector+23+Dwarka+Delhi+110077" target="_blank" rel="noreferrer" className="address-link" data-testid="link-open-map">Find us on the map <ArrowUpRight size={15} /></a>
          </div>
        </div>
      </section>

      <footer className="site-footer">
        <div className="page-wrap footer-top">
          <a href="#top" className="brand footer-brand" data-testid="link-footer-home"><span className="brand-mark"><svg viewBox="0 0 42 42" fill="none"><path d="M8 28C8 16 17 7 34 7c0 15-8 27-20 27" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" /><path d="M11 34c5-9 11-15 20-21M6 35h18" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" /><circle cx="33" cy="31" r="3" fill="#E87537" /></svg></span><span className="brand-copy"><strong>jiya</strong><small>AGRO FOODS</small></span></a>
          <p>India's agricultural produce,<br />made useful for food makers.</p>
          <div className="footer-links"><a href="#range" data-testid="link-footer-range">Our range</a><a href="#approach" data-testid="link-footer-about">Our approach</a><a href="#contact" data-testid="link-footer-contact">Contact</a></div>
          <a className="footer-back-top" href="#top" aria-label="Back to top" data-testid="link-back-to-top"><ArrowUpRight size={18} /></a>
        </div>
        <div className="page-wrap footer-bottom"><span>© {new Date().getFullYear()} Jiya Agro Foods</span><span>ROOTED IN AGRICULTURE. READY FOR WHAT'S NEXT.</span><span>HARYANA · INDIA</span></div>
      </footer>
      <ChatWidget />
    </main>
  );
}
