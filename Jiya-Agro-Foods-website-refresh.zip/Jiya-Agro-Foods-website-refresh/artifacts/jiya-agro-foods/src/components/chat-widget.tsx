import { type FormEvent, useRef, useState } from 'react';
import { useSendChatReply } from '@workspace/api-client-react';
import { ArrowUp, Bot, ChevronDown, MessageCircle, RotateCcw, X } from 'lucide-react';

type Turn = { role: 'user' | 'assistant'; content: string };
const greeting = 'Hello. I can help with our onion and garlic powders, flakes, or a product enquiry. What would you like to know?';
const suggestions = [
  'What is the difference between onion powder and flakes?',
  'How can I enquire about a supply requirement?',
];

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [draft, setDraft] = useState('');
  const [lastQuestion, setLastQuestion] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const endRef = useRef<HTMLDivElement>(null);
  const sendReply = useSendChatReply();

  const ask = (value: string) => {
    const question = value.trim();
    if (!question || sendReply.isPending) return;
    const userTurn: Turn = { role: 'user', content: question };
    const priorTurns = turns.slice(-14);
    setLastQuestion(question);
    setTurns((current) => [...current, userTurn]);
    setDraft('');
    setErrorMessage('');
    sendReply.mutate(
      { data: { messages: [...priorTurns, userTurn] } },
      {
        onSuccess: (result) => {
          addAssistantReply(result.reply);
          window.setTimeout(() => endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }), 30);
        },
        onError: () => setErrorMessage('That did not come through. Please try again, or contact our team directly.'),
      },
    );
  };

  const addAssistantReply = (reply: string) => {
    setTurns((current) => [...current, { role: 'assistant', content: reply }]);
  };

  const retryLastQuestion = () => {
    if (!lastQuestion || sendReply.isPending) return;
    const priorTurns = turns.at(-1)?.role === 'user' ? turns.slice(0, -1).slice(-14) : turns.slice(-14);
    setErrorMessage('');
    sendReply.mutate(
      { data: { messages: [...priorTurns, { role: 'user', content: lastQuestion }] } },
      {
        onSuccess: (result) => {
          addAssistantReply(result.reply);
          window.setTimeout(() => endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }), 30);
        },
        onError: () => setErrorMessage('That did not come through. Please try again, or contact our team directly.'),
      },
    );
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    ask(draft);
  };

  return (
    <div className="chat-root">
      {isOpen && (
        <section className="chat-panel" aria-label="Jiya customer chat" data-testid="panel-customer-chat">
          <div className="chat-head">
            <span className="chat-bot-mark"><Bot size={19} /></span>
            <div><strong>Ask Jiya</strong><small>Product & enquiry help</small></div>
            <button type="button" className="chat-close" aria-label="Close chat" onClick={() => setIsOpen(false)} data-testid="button-close-chat"><X size={18} /></button>
          </div>
          <div className="chat-messages" aria-live="polite">
            <div className="chat-row assistant-row">
              <div className="chat-bubble assistant-bubble" data-testid="text-chat-greeting">{greeting}</div>
            </div>
            {turns.map((turn, index) => (
              <div className={`chat-row ${turn.role === 'user' ? 'user-row' : 'assistant-row'}`} key={`${turn.role}-${index}`}>
                <div className={`chat-bubble ${turn.role === 'user' ? 'user-bubble' : 'assistant-bubble'}`} data-testid={`text-chat-${turn.role}-${index}`}>{turn.content}</div>
              </div>
            ))}
            {sendReply.isPending && (
              <div className="chat-row assistant-row" role="status" data-testid="status-chat-pending">
                <div className="chat-bubble assistant-bubble typing"><i /><i /><i /><span>Finding a helpful answer</span></div>
              </div>
            )}
            {errorMessage && (
              <div className="chat-error" role="alert" data-testid="status-chat-error">
                <span>{errorMessage}</span>
                <button type="button" onClick={retryLastQuestion} disabled={sendReply.isPending} data-testid="button-retry-chat"><RotateCcw size={13} /> Try again</button>
              </div>
            )}
            {turns.length === 0 && (
              <div className="chat-suggestions">
                <span>QUICK QUESTIONS</span>
                {suggestions.map((question, index) => (
                  <button type="button" key={question} onClick={() => ask(question)} disabled={sendReply.isPending} data-testid={`button-chat-suggestion-${index}`}>
                    {question}<ArrowUp size={13} />
                  </button>
                ))}
              </div>
            )}
            <div ref={endRef} />
          </div>
          <form className="chat-compose" onSubmit={submit}>
            <input value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Ask about our ingredients…" aria-label="Your question" maxLength={1000} data-testid="input-chat-question" />
            <button type="submit" aria-label="Send question" disabled={!draft.trim() || sendReply.isPending} data-testid="button-send-chat"><ArrowUp size={17} /></button>
          </form>
          <div className="chat-foot">For a direct enquiry, call <a href="tel:+919138001617" data-testid="link-chat-phone">+91 91380 01617</a></div>
        </section>
      )}
      <button className={`chat-launcher ${isOpen ? 'chat-launcher-open' : ''}`} type="button" aria-label={isOpen ? 'Minimise chat' : 'Chat with Jiya'} onClick={() => setIsOpen((open) => !open)} data-testid="button-open-chat">
        {isOpen ? <ChevronDown size={21} /> : <><MessageCircle size={20} /><span>Ask us</span></>}
      </button>
    </div>
  );
}
