import { ArrowRight, Check } from 'lucide-react';

type ProductFeatureProps = {
  id: string;
  number: string;
  name: string;
  descriptor: string;
  image: string;
  imageAlt: string;
  tint: 'onion' | 'garlic';
  intro: string;
  highlights: string[];
  applications: string;
  note: string;
};

export function ProductFeature({ id, number, name, descriptor, image, imageAlt, tint, intro, highlights, applications, note }: ProductFeatureProps) {
  return (
    <article id={id} className={`product-feature product-${tint}`}>
      <div className="product-copy">
        <div className="product-overline"><span>{number}</span><i /> DEHYDRATED POWDER</div>
        <h3 className="product-title">{name}</h3>
        <p className="product-descriptor">{descriptor}</p>
        <p className="product-intro">{intro}</p>
        <ul className="product-points">
          {highlights.map((highlight) => <li key={highlight}><span><Check size={13} /></span>{highlight}</li>)}
        </ul>
        <div className="product-use">
          <span>IN THE KITCHEN</span>
          <p>{applications}</p>
        </div>
        <div className="product-actions">
          <a className="button-primary" href="#contact" data-testid={`link-enquire-${tint}`}>Enquire about this product <ArrowRight size={16} /></a>
          <span>{note}</span>
        </div>
      </div>
      <div className="product-visual">
        <div className="product-photo" data-testid={`img-product-${tint}`}>
          <img src={image} alt={imageAlt} loading="lazy" />
          <div className="photo-caption"><span>JIYA AGRO FOODS</span><span>{number} / 02</span></div>
        </div>
        <div className="product-side-label" aria-hidden="true">SINGLE INGREDIENT · READY TO USE</div>
      </div>
    </article>
  );
}
