import { useState } from 'react';
import { ArrowUpRight, Menu, X } from 'lucide-react';

const links = [
  { label: 'Our range', href: '#range' },
  { label: 'Why Jiya', href: '#approach' },
  { label: 'How to use', href: '#applications' },
  { label: 'Contact', href: '#contact' },
];

export function SiteHeader() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="site-header">
      <div className="page-wrap header-inner">
        <a href="#top" className="brand" aria-label="Jiya Agro Foods home" data-testid="link-home">
          <span className="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 42 42" fill="none">
              <path d="M8 28C8 16 17 7 34 7c0 15-8 27-20 27" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" />
              <path d="M11 34c5-9 11-15 20-21M6 35h18" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
              <circle cx="33" cy="31" r="3" fill="#E87537" />
            </svg>
          </span>
          <span className="brand-copy"><strong>jiya</strong><small>AGRO FOODS</small></span>
        </a>

        <nav className={`main-nav ${menuOpen ? 'is-open' : ''}`} aria-label="Main navigation">
          {links.map((link) => (
            <a key={link.href} href={link.href} onClick={() => setMenuOpen(false)} data-testid={`link-nav-${link.label.toLowerCase().replaceAll(' ', '-')}`}>{link.label}</a>
          ))}
          <a className="nav-enquire" href="#contact" onClick={() => setMenuOpen(false)} data-testid="link-nav-enquire">Talk to our team <ArrowUpRight size={15} /></a>
        </nav>

        <button className="menu-toggle" type="button" aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)} data-testid="button-toggle-menu">
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>
    </header>
  );
}
